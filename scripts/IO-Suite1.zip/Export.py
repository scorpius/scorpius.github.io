# +---------------------------------------------------------+
# | Copyright (c) 2002 Anthony D'Agostino                   |
# | http://www.redrival.com/scorpius                        |
# | scorpius@compuserve.com                                 |
# | April 16, 2002                                          |
# | Radiosity Import Export Suite v0.5                      |
# +---------------------------------------------------------+

import sys, os
import radiosity, truespace, lightwave, off, raw, lightflow, patches, nendo
import meshtools

meshtools.show_progress = 1 	# Set to 0 for faster performance.
meshtools.average_vcols = 1 	# off for per-face, on for per-vertex

def getfilename(fs):
	try:
		filename = fs.filename.lower()
	except:
		filename = fs.lower()

	extension = os.path.splitext(filename)[1]

	if extension == ".radio":
		radiosity.write(filename)
	elif extension == ".cob":
		truespace.write(filename)
	elif extension == ".lwo":
		lightwave.write(filename)
	elif extension == ".off":
		off.write(filename)
	elif extension == ".ndo":
		nendo.write(filename)
	elif extension == ".wings":
		import wings
		wings.write(filename)
	elif extension == ".raw":
		raw.write(filename)
	elif extension == ".mesh":
		lightflow.write(filename)
	else:
		print "The " + extension + " file format can't be exported."
	sys.stdout.flush()

try:
	import GUI
	fs = GUI.FileSelector()
	fs.activate(getfilename, fs)
except:
	import Blender
	Blender.Window.FileSelector(getfilename, "Export File")

#  ==============================================
#
#                    N O T E:
#
#  Select a mesh object, press Alt-P to run this
#  script, then left-click on a file and
#  manually change the extension to .cob, lwo,
#  .off, or .radio, depending on which format
#  you want to export.
#
#  Warning: middle clicking on any file will
#  overwrite the contents without warning.
#
#  Before exporting to .cob format, the mesh
#  must have real-time uv coordinates.	Press
#  the FKEY to assign them.  Vertex colors will
#  be exported, if they are present.
#
#  Before exporting to .radio format, the mesh
#  must have vertex colors.  Here's how to
#  assign them:
#
#  1.  Use radiosity! (cornell_box.radio)
#  2.  Set up lights and materials, select a
#	   mesh, press Ctrl-Z, press the VKEY.
#	   (sphere.radio)
#  3.  Press the VKEY and paint manually.
#	   (hand.radio)
#  4.  Use a custom script to calculate and
#	   apply simple diffuse shading and
#	   specular highlights to the vertex
#	   colors. (torus-knot.radio)
#  5.  The Videoscape format also allows vertex
#	   colors to be specified.
#	   (VIDEOSCAPE_quad.obj)
#
#  Tested with Blender 2.23 and Python 2.0 (all
#  meshes created with Blender).
#
#  ==============================================
