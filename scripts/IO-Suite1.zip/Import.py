# +---------------------------------------------------------+
# | Copyright (c) 2002 Anthony D'Agostino                   |
# | http://www.redrival.com/scorpius                        |
# | scorpius@compuserve.com                                 |
# | April 16, 2002                                          |
# | Radiosity Import Export Suite v0.5                      |
# +---------------------------------------------------------+

import sys, os
import radiosity, truespace, lightwave, off, raw, lightflow, patches, nendo
import meshtools

meshtools.show_progress = 1 	# Set to 0 for faster performance.
meshtools.overwritemesh = 1 	# Set to 0 to increment object-name version

p1 = 'r:/resources/amazing3d/'
p2 = 'd:/misc/trueSpace3/objects'
p3 = 'd:/misc/trueSpace5 Trial/library/objects.obl'
p4 = 'f:/obj'
p5 = os.getcwd()

os.chdir(p5)

def getfilename(fs):
	try:
		filename = fs.filename.lower()
	except:
		filename = fs.lower()
	
	extension = os.path.splitext(filename)[1]

	if extension == ".radio":
		radiosity.read(filename)
	elif extension == ".cob" or extension == ".scn":
		truespace.read(filename)
	elif extension == ".lwo":
		lightwave.read(filename)
	elif extension == ".off":
		off.read(filename)
	elif extension == ".ndo":
		nendo.read(filename)
	elif extension == ".wings":
		import wings
		wings.read(filename)
	elif extension == ".raw":
		raw.read(filename)
	elif extension == ".mesh":
		lightflow.read(filename)
	elif extension == "":
		patches.read(filename)
	elif extension == ".gz" or extension == ".xml":
		import yafray
		yafray.read(filename)
	else:
		print "The " + extension + " file format can't be imported."
	sys.stdout.flush()

try:
	import GUI
	fs = GUI.FileSelector()
	fs.activate(getfilename, fs)
except:
	import Blender
	Blender.Window.FileSelector(getfilename, "Import File")


# -------------------------------------------------------------------------
# print Blender.Window.FileSelector.__doc__
#
# (callback [, title]) - Open a file selector window.
# The selected filename is used as argument to a function callback f(name)
# that you must provide. 'title' is optional and defaults to 'SELECT FILE'.
#
# Example:
#
# import Blender
#
# def my_function(filename):
#	print 'The selected file was: ', filename
#
# Blender.Window.FileSelector(my_function, 'SAVE FILE')
# -------------------------------------------------------------------------


# -------------------------------------------------------------------------
# print dir(Blender.Window)
#
# ['DrawProgressBar', 'FileSelector', 'ImageSelector', 'QRedrawAll', 'Redraw',
# 'RedrawAll', 'Types', '__doc__', '__name__', 'drawProgressBar']
# -------------------------------------------------------------------------




#  ==============================================
#
#                    N O T E:
#
#  Press Alt-P to run this script, then
#  middle-click on a file with a .cob, .scn,
#  .lwo, .off, or .radio extension.
#
#  Check the DOS window for errors and other
#  messages.
#
#  Tested with Blender 2.23 and Python 2.0 (all
#  meshes created with Blender).
#
#  ==============================================
