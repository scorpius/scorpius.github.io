# +-------------------------------------------------------+
# | Copyright (c) 2001 Anthony C. D'Agostino              |
# | http://ourworld.compuserve.com/homepages/scorpius     |
# | scorpius@compuserve.com                               |
# | February 3, 2001                                      |
# | Writes the selected mesh to OFF                       |
# +-------------------------------------------------------+

import Blender
import math, sys
from Blender import NMesh, Object
from math import *

object = Object.GetSelected()
objname = object[0].name
meshname = object[0].data.name
mesh = NMesh.GetRaw(meshname)

filename = objname+".off"
file = open(filename, "w")
std=sys.stdout
sys.stdout=file

print "OFF"
print len(mesh.verts), len(mesh.faces), "0"

for vertex in mesh.verts:
    x = vertex.co[0]
    y = vertex.co[1]
    z = vertex.co[2]
    print "%f %f %f" % (x, y, z)

for face in mesh.faces:
    print len(face.v),
    #face.v.reverse()  # flip normals
    for vertex in face.v:
        print vertex.index,
    print

sys.stdout=std
file.close()

print "Saved to", filename