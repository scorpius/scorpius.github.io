%% N-Torus Plugin
%% Includes two other types of tori borrowed from LightFlow.
%% Copyright (c) 2002 Anthony D'Agostino (scorpius@netzero.com)
%%
%% Allows one to specify the U/V resolution and the major/minor radius.
%% The U resolution is the number of faces that will be generated
%% along the path of the major radius; the V resolution, along the path
%% of the minor radius.
%%
%% To generate square faces, rather than long and thin rectangles,
%% maintain the following ratio:
%%
%%			U Resolution   Major Radius
%%			------------ = ------------
%%			V Resolution   Minor Radius
%%
%% Check my page for updates and an interactive torus generator plugin
%% for Blender.  http://www.redrival.com/scorpius

-module(wpc_torus).
-export([init/0,menu/2,command/2]).

-import(math, [sqrt/1,cos/1,sin/1,pi/0]).

init() -> true.

menu({shape,more}, []) ->
	torus_menu();
menu({shape,more}, Menu) ->
	Menu ++ [separator|torus_menu()];
menu(_, Menu) -> Menu.

torus_menu() ->
	[{"N-Torus"      ,uvtorus,[option]},
	 {"Lumpy Torus"  ,lutorus,[option]},
	 {"Spiral Torus" ,sptorus,[option]}].

command({shape,{more,{uvtorus,Ask}}}, _St) -> make_uvtorus(Ask);
command({shape,{more,{lutorus,Ask}}}, _St) -> make_lutorus(Ask);
command({shape,{more,{sptorus,Ask}}}, _St) -> make_sptorus(Ask);
command(_, _) -> next.

%%% The rest are local functions.

% ======= Regular Torus =======
make_uvtorus(Ask) when is_atom(Ask) ->
	wpa:ask(Ask, "N-Torus Options",
		[{"U Resolution",60},
		 {"V Resolution",12},
		 {"Major Radius",1.0},
		 {"Minor Radius",0.2}],
		fun(Res) -> {shape,{more,{uvtorus,Res}}} end);
make_uvtorus([URES, VRES, MajR, MinR]) ->
	case {URES>0, VRES>0} of
		{true, true} ->
			Ures = URES,
			Vres = VRES;
		{false, true} ->
			Ures = trunc(VRES*(MajR/MinR)),
			Vres = VRES;
		{true, false} ->
			Vres = trunc(URES/(MajR/MinR)),
			Ures = URES
	end,
	% io:fwrite("\nU, V: ~p ~p", [Ures, Vres]),
	Vs = uvtorus_verts(Ures, Vres, MajR, MinR),
	Fs = uvtorus_faces(Ures, Vres),
	{new_shape,"N-Torus",Fs,Vs}.

% ======= Lumpy Torus =======
make_lutorus(Ask) when is_atom(Ask) ->
	wpa:ask(Ask, "Lumpy Torus Options",
		[{"U Resolution",125},
		 {"V Resolution",25},
		 {"Major Radius",1.0},
		 {"Minor Radius",0.2},
		 {"Lumps",8},
		 {"Lump Amplitude",0.5}],
		fun(Res) -> {shape,{more,{lutorus,Res}}} end);
make_lutorus([Ures, Vres, MajR, MinR, Loops, LoopRad]) ->
	Vs = lutorus_verts(Ures, Vres, MajR, MinR, Loops, LoopRad),
	Fs = uvtorus_faces(Ures, Vres),
	{new_shape,"Lumpy Torus",Fs,Vs}.

% ======= Spiral Torus =======
make_sptorus(Ask) when is_atom(Ask) ->
	wpa:ask(Ask, "Spiral Torus Options",
		[{"U Resolution",200},
		 {"V Resolution",20},
		 {"Major Radius",1.0},
		 {"Minor Radius",0.2},
		 {"Loops       ",8},
		 {"Loop Radius ",0.2}],
		fun(Res) -> {shape,{more,{sptorus,Res}}} end);
make_sptorus([Ures, Vres, MajR, MinR, Loops, LoopRad]) ->
	Vs = sptorus_verts(Ures, Vres, MajR, MinR, Loops, LoopRad),
	Fs = uvtorus_faces(Ures, Vres),
	{new_shape,"Spiral Torus",Fs,Vs}.


% theta = (I*2*pi()/Ures)
% phi	= (J*2*pi()/Vres)
uvtorus_verts(Ures, Vres, MajR, MinR) ->
	Du = 2*pi()/Ures, % Delta U
	Dv = 2*pi()/Vres, % Delta V
	Verts = [
			{
			(MajR + MinR*cos(J*Dv)) * cos(I*Du),
				  -(MinR*sin(J*Dv)),
			(MajR + MinR*cos(J*Dv)) * sin(I*Du)
			} % this tuple contains the x,y,z coordinates of this vertex
			|| I <- lists:seq(0, Ures-1), J <- lists:seq(0, Vres-1)],
	Verts.

lutorus_verts(Ures, Vres, MajR, MinR, Loops, LoopRad) ->
	Du = 2*pi()/Ures, % Delta U
	Dv = 2*pi()/Vres, % Delta V
	Verts = [
			{
			(MajR + MinR*cos((J*Dv))*(1.0+cos((I*Du)*Loops)*LoopRad)) * cos((I*Du)),
				  -(MinR*sin((J*Dv))*(1.0+cos((I*Du)*Loops)*LoopRad)),
			(MajR + MinR*cos((J*Dv))*(1.0+cos((I*Du)*Loops)*LoopRad)) * sin((I*Du))
			} % this tuple contains the x,y,z coordinates of this vertex
			|| I <- lists:seq(0, Ures-1), J <- lists:seq(0, Vres-1)],
	Verts.

sptorus_verts(Ures, Vres, MajR, MinR, Loops, LoopRad) ->
	Du = 2*pi()/Ures, % Delta U
	Dv = 2*pi()/Vres, % Delta V
	Verts = [
			{
			(MajR + MinR*cos((J*Dv)) + sin((I*Du)*Loops)*LoopRad) * cos((I*Du)),
				  -(MinR*sin((J*Dv)) + cos((I*Du)*Loops)*LoopRad),
			(MajR + MinR*cos((J*Dv)) + sin((I*Du)*Loops)*LoopRad) * sin((I*Du))
			} % this tuple contains the x,y,z coordinates of this vertex
			|| I <- lists:seq(0, Ures-1), J <- lists:seq(0, Vres-1)],
	Verts.

uvtorus_faces(Ures, Vres) ->
	Faces = [
			[
			J + I*Vres,
			J + ((I+1) rem Ures) * Vres,
			(J+1) rem Vres + ((I+1) rem Ures)*Vres,
			(J+1) rem Vres + I*Vres
			] % this list contains the list of vertex indices in this face (a quad)
			|| I <- lists:seq(0, Ures-1), J <- lists:seq(0, Vres-1)],
	Faces.

