%% MeshTools
%% Functions For Manipulating Meshes (for use with primitive plugins)
%% Copyright (c) 2003 Anthony D'Agostino (scorpius@netzero.com)
%%
%% For updates and other plugins:
%% http://www.redrival.com/scorpius

-module(meshtools).
-include("e3d.hrl").
-export([
	obj_output/2,
	obj_output/3,
	clean_quad_mesh/2,
	zip_lists2/2,
	zip_lists3/3,
	flip_normals/1,
	spherize_verts/1,
	remove_dups/1,
	indexed_to_raw/2,
	raw_to_indexed/1,
	add_indices/1,
	flip_normals/1,
	make_keyvalue_list/2,
	print/1,
	faces_to_e3dfaces/1,
	e3dfaces_to_faces/1]).

obj_output(Verts, Faces, FileName) ->
	case (FileName==none) of
		true -> IoDevice = standard_io;
		false -> {ok, IoDevice} = file:open(FileName, write)
	end,
	Print_Vert = fun(Vertex) ->
		{X,Y,Z} = Vertex,
		io:fwrite(IoDevice, "v ~9f ~9f ~9f\n", [X,Y,Z]) end,
	Print_Idx = fun(Index) ->
		io:fwrite(IoDevice, " ~w", [Index+1]) end,
	Print_Face = fun(Face) ->
		io:put_chars(IoDevice, "f"),
		lists:foreach(Print_Idx, Face),
		io:put_chars(IoDevice, "\n") end,
	io:fwrite(IoDevice, "# NumVerts: ~p\n", [length(Verts)]),
	io:fwrite(IoDevice, "# NumFaces: ~p\n", [length(Faces)]),
	io:put_chars(IoDevice, "g Mesh\n"),
	lists:foreach(Print_Vert, Verts),
	lists:foreach(Print_Face, Faces),
	file:close(IoDevice).

obj_output(Verts, Faces) ->
	obj_output(Verts, Faces, none).

print(Item) ->
	io:fwrite("~p\n", [Item]).

% ============================
% === Quads <--> Triangles ===
% ============================
quads_to_triangles(Faces) ->
	Triangulate_A_Quad = fun([A,B,C,D]) -> [[A,B,C],[C,D,A]] end,
	Triangles = lists:map(Triangulate_A_Quad, Faces),
	lists:append(Triangles).				% convert to a list of lists

triangles_to_quads([]) -> [];				% Only for use in conjunction with
triangles_to_quads(Faces) ->				% quads_to_triangles().
	[Face1,Face2 | RestOfFaces] = Faces,
	[Index1,Index2,Index3] = Face1,
	Index4 = lists:nth(2, Face2),
	Quad = [Index1,Index2,Index3,Index4],
	[Quad | triangles_to_quads(RestOfFaces)].

% ========================
% === Indexed <--> Raw ===
% ========================

% indexed_to_raw(Verts, Faces) ->			  % replace indices with values
%	  Make_Raw_Triangle = fun(Face) ->
%		  [Index1,Index2,Index3] = Face,
%		  [lists:nth(Index1+1, Verts),
%		   lists:nth(Index2+1, Verts),
%		   lists:nth(Index3+1, Verts) ] end,
%	  lists:map(Make_Raw_Triangle, Faces).

indexed_to_raw(Verts, Faces) -> 			% replace indices with values
	Make_Raw_Face = fun(Face) ->
		[lists:nth(Index+1, Verts) || Index <- Face] end,
	lists:map(Make_Raw_Face, Faces).

% wrong!
% indexed_to_raw(Verts, Faces) ->			  % replace indices with values
%	  [lists:nth(Index+1, Verts) || Face <- Faces, Index <- Face].
%	  % py: [[Verts[i] for i in face] for face in Faces]

raw_to_indexed(RawTriangles) -> 			% replace values with indices
	VertsWithDups = lists:append(RawTriangles),
	Verts = remove_dups(VertsWithDups), 	% Zero tolerance
	IndexedVerts = dict:from_list(add_indices(Verts)),
	Get_Index = fun(Vertex) -> dict:fetch(Vertex, IndexedVerts) end,
	Process_Face = fun(Face) -> lists:map(Get_Index, Face) end,
	Faces = lists:map(Process_Face, RawTriangles),	% re-indexes the Faces list
	{Verts, Faces}.

remove_dups(VertsWithDups) ->				% return a list of unique verts
	Make_KeyValue_Pair = fun(Vertex) -> {Vertex, none} end,
	A = lists:map(Make_KeyValue_Pair, VertsWithDups),
	B = dict:from_list(A),
	dict:fetch_keys(B).

add_indices(Verts) ->
	NumVerts = length(Verts),
	Indices = lists:seq(0, NumVerts-1),
	%$IndexedList = make_keyvalue_list(Verts, Indices),
	IndexedList = lists:zip(Verts, Indices),
	IndexedList.

% =============
% === Other ===
% =============
spherize_verts(Verts) ->
	lists:map({vectors, vunit}, Verts).

flip_normals(Faces) ->
	reverse_list_of_lists(Faces).

clean_quad_mesh(Verts, Faces) ->
	Triangles = quads_to_triangles(Faces),
	RawTriangles = indexed_to_raw(Verts, Triangles),
	{Vs, Tris} = raw_to_indexed(RawTriangles),
	Fs = triangles_to_quads(Tris),
	{Vs, Fs}.

% ======================
% === Misc Functions ===
% ======================
reverse_list_of_lists(LOL) ->
	Reverse = fun(List) -> lists:reverse(List) end,
	lists:map(Reverse, LOL).

zip_lists2([], []) -> [];	% Zip two lists together, two elements at a time.
zip_lists2(A, B) -> 		% Both lists must be equal in length
	[HA1,HA2 | TA] = A, 	% and must have an even number of elements
	[HB1,HB2 | TB] = B,
	lists:flatten([[HA1,HA2,HB1,HB2] | zip_lists2(TA, TB)]).

zip_lists3([], [], []) -> [];	% Zip three lists together, one element at a time.
zip_lists3(A, B, C) ->			% All lists must be equal in length.
	[H1|T1] = A,
	[H2|T2] = B,
	[H3|T3] = C,
	lists:flatten([[H1,H2,H3] | zip_lists3(T1, T2, T3)]).

make_keyvalue_list([], []) -> [];
make_keyvalue_list(Keys, Vals) ->
	[Key | RestOfKeys] = Keys,
	[Val | RestOfVals] = Vals,
	[{Key,Val} | make_keyvalue_list(RestOfKeys, RestOfVals)].

e3dfaces_to_faces(E3dFaces) ->
	[E3dFace#e3d_face.vs || E3dFace <- E3dFaces].

% e3dfaces_to_faces(E3dFaces) -> #Old
%	  GetFaceIndices = fun(E3dFace) ->
%		  #e3d_face{vs=FaceVs} = E3dFace,
%		  FaceVs end,
%	  lists:map(GetFaceIndices, E3dFaces).

faces_to_e3dfaces(Faces) ->
	[#e3d_face{vs=Face} || Face <- Faces].

% reverse_list_of_lists([]) -> [];
% reverse_list_of_lists(LOL) ->
%	  [H|T] = LOL,
%	  [lists:reverse(H)|reverse_list_of_lists(T)].

% zip_lists1([], []) -> [];   % Zip two lists together, one element at a time.
% zip_lists1(A, B) ->		  % Both lists must be equal in length.
%	  [H1|T1] = A,
%	  [H2|T2] = B,
%	  lists:flatten([[H1,H2] | zip_lists1(T1, T2)]).

% remove_dups_2(VertsWithDups) ->			  % return a list of unique verts
%	  lists:usort(VertsWithDups).
