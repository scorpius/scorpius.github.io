%% Vectors
%% A simple vector module (I should have used e3d_vec.erl).
%% Copyright (c) 2003 Anthony D'Agostino (scorpius@netzero.com)
%%
%% For updates and other plugins:
%% http://www.redrival.com/scorpius

-module(vectors).
-export([vadd/2, vsub/2, vmul/2, vdiv/2, vcross/2, vunit/1, vlen/1, vdot/2,
		 vdot2/2, vsplit/2 ]).
-export([main/0]).

vadd(U, V) ->	% Returns a vector {u+v}
	{Ux, Uy, Uz} = U,
	{Vx, Vy, Vz} = V,
	{Ux+Vx, Uy+Vy, Uz+Vz}.

vsplit(U, V) -> % Returns a vector, the midpoint of {u, v} ?
	{Ux, Uy, Uz} = U,
	{Vx, Vy, Vz} = V,
	{(Ux+Vx)/2, (Uy+Vy)/2, (Uz+Vz)/2}.

vsub(U, V) ->	% Returns a vector from point v to point u {u-v}
	{Ux, Uy, Uz} = U,
	{Vx, Vy, Vz} = V,
	{Ux-Vx, Uy-Vy, Uz-Vz}.

vmul(U, S) ->	% Returns a vector {u*scalar}
	{Ux, Uy, Uz} = U,
	{Ux*S, Uy*S, Uz*S}.

vdiv(U, S) ->	% Returns a vector {u/scalar}
	{Ux, Uy, Uz} = U,
	{Ux/S, Uy/S, Uz/S}.

vcross(U, V) -> % Returns a vector {u*v} Cross Product
	{Ux, Uy, Uz} = U,
	{Vx, Vy, Vz} = V,
	{Uy*Vz-Uz*Vy, Uz*Vx-Ux*Vz, Ux*Vy-Uy*Vx}.

vunit(U) -> 	% Returns a vector of unit length (normalized)
	vmul(U, 1/vlen(U)).

vlen(U) ->		% Returns a real number (Vector Length)
	{Ux, Uy, Uz} = U,
	math:sqrt(Ux*Ux + Uy*Uy + Uz*Uz).

vdot(U, V) ->	% Returns a real number (Dot Product)
	{Ux, Uy, Uz} = U,
	{Vx, Vy, Vz} = V,
	Ux*Vx + Uy*Vy + Uz*Vz.

vdot2(U, V) ->	% Returns the cosine of theta in the range (0, 1)
	CosTheta = vdot(U, V),
	case CosTheta > 0.0 of
		true ->  Result = CosTheta;
		false -> Result = 0
	end,
	Result.

% Test functions
main() ->
	T = (math:sqrt(5)-1)/2,
	A = {0, 1, T},
	B = {0, 1, -T},

	print("T             :", T),
	print("A             :", A              ),
	print("B             :", B              ),

	print("vadd(A, B)    :", vadd(A, B)     ),
	print("vsub(A, B)    :", vsub(A, B)     ),
	print("vcross(A, B)  :", vcross(A, B)   ),
	print("vmul(B, 3)    :", vmul(B, 3)     ),

	print("vdot(A, B)    :", vdot(A, B)     ),
	print("vdot2(A, B)   :", vdot2(A, B)    ),
	print("vlen(A)       :", vlen(A)        ),
	print("vlen(B)       :", vlen(B)        ),
	print("vunit(A)      :", vunit(A)       ),
	print("vunit(B)      :", vunit(B)       ),

	print("vdot(Ua, Ub)  :", [vdot(vunit(A), vunit(B))] ),
	print("vcross(Ua, Ub):", [vcross(vunit(A), vunit(B)), vunit(vcross(A, B))] ),

	print("Angle         :", math:acos(vdot(vunit(A), vunit(B)))*180/math:pi() ),

	done.

% print(Item) -> io:fwrite("~p\n", [Item]).

print(Item1, Item2) ->
	io:fwrite("~p ~p\n", [Item1, Item2]).

