%% SLP Plugin
%% Import/Export Pro/Engineer SLP File Format (*.slp)
%% Copyright (c) 2005 Anthony D'Agostino (scorpius@netzero.com)
%%
%% For updates and other plugins:
%% http://chronosphere.home.comcast.net

-module(wpc_slp).
-export([init/0, menu/2, command/2]).
-include("e3d.hrl").

init() ->
    true.

menu({file, import}, Menu) ->
	menu_entry(Menu);
% menu({file, export}, Menu) ->
%	  menu_entry(Menu);
% menu({file, export_selected}, Menu) ->
%	  menu_entry(Menu);
menu(_, Menu) -> Menu.


command({file, {import, slp}}, St) ->
	Props = props(),
	wpa:import(Props, fun slp_import/1, St);
command({file, {export, slp}}, St) ->
	Props = props(),
	wpa:export(Props, fun export/2, St);
command({file, {export_selected, slp}}, St) ->
    Props = props(),
    wpa:export_selected(Props, fun export/2, St);
command(_, _) -> next.

menu_entry(Menu) ->
	Menu ++ [{"Pro/Engineer SLP (.slp)...", slp}].

props() ->
	[{ext, ".slp"},{ext_desc, "Pro/Engineer SLP File"}].

% ===============================
% === Pro/Engineer SLP Export ===
% ===============================
export(FileName, Contents) ->
	SLP = make_slp(Contents),
	file:write_file(FileName, SLP).

make_slp(Contents) ->
	#e3d_file{objs=Objs,creator=Creator} = Contents,
	%io:fwrite("Number of Objects: ~p\n", [length(Objs)]),
	%io:fwrite("~P\n", [Contents, 120]),
	%io:fwrite("~P\n", [Objs, 120]),
	StlHead = make_header(Creator),
	CombinedObj = combine_objs(Objs),
	StlBody = make_body(CombinedObj),
	[StlHead|StlBody].

combine_objs(Objs) ->
	VFs = [get_vf_lists(Obj) || Obj <- Objs],
	{AllVs,AllFs} = lists:unzip(VFs),
	Nvs = lists:map({erlang,length}, AllVs),
	Incs = get_incs(Nvs),
	Vs = lists:append(AllVs),
	Fs = lists:append(reindex_faces(Incs, AllFs)),
	{Vs,Fs}.

get_incs(L) ->
	A = lists:reverse(L),
	B = make_incs(A),
	lists:reverse(B).

make_incs([]) -> [];
make_incs(L) ->
	[_|T] = L,
	[lists:sum(T) | make_incs(T)].

get_vf_lists(Obj) ->
	#e3d_object{obj=Mesh} = Obj,
	#e3d_mesh{vs=Vs,fs=Fs} = e3d_mesh:triangulate(Mesh),
	{Vs, e3dfaces_to_faces(Fs)}.

reindex_faces([], []) -> [];
reindex_faces(Incs, AllFs) ->
	Add = fun(X) -> fun(Y) -> X+Y end end,
	[Inc|RestIncs] = Incs,
	[Fs|RestFs] = AllFs,
	[[lists:map(Add(Inc), F) || F<-Fs] | reindex_faces(RestIncs, RestFs)].

make_header(Creator) -> % An 80 Byte Header
	A = "Exported from " ++ Creator,
	B = "\nSLP plugin written by Anthony D'Agostino\n2005",
	C = list_to_binary([A,B]),
	size(C) =< 80,
	<<C/binary, 0:((80-size(C))*8)>>.

make_body({Vs, Fs}) ->
	NumFaces = <<(length(Fs)):32/little>>,
	RawTriangles = meshtools:indexed_to_raw(Vs, Fs),
	[NumFaces|raw_triangles_to_bin(RawTriangles)].

raw_triangles_to_bin(RawTriangles) ->
	VertToBinary = fun(Vertex) ->
		{X,Y,Z} = Vertex,
		<<X:32/float-little, -Z:32/float-little, Y:32/float-little>> end,
	TriToBinary = fun(Triangle) ->
		FaceNorm = <<0:32/float-little, 0:32/float-little, 0:32/float-little>>,
		FaceVerts = lists:map(VertToBinary, Triangle),
		FacePad = <<0:16>>, % can be used for 16-bit RGB color extension
		[FaceNorm, FaceVerts, FacePad] end,
	lists:map(TriToBinary, RawTriangles).

e3dfaces_to_faces(E3dFaces) ->
	[FaceVs || #e3d_face{vs=FaceVs} <- E3dFaces].

% e3dfaces_to_faces(E3dFaces) ->
%	  GetFaceIndices = fun(E3dFace) ->
%		  #e3d_face{vs=FaceVs} = E3dFace,
%		  FaceVs end,
%	  lists:map(GetFaceIndices, E3dFaces).

% ===============================
% === Pro/Engineer SLP Import ===
% ===============================
slp_import(Name) ->
	case file:read_file(Name) of
	{ok,Bin} ->
		print_boxed("FileName: " ++ Name),
		Res = import(Bin),
		Res;
	{error,Reason} ->
		{error,file:format_error(Reason)}
	end.

import(Data) ->
	{Vs,Fs} = read_slp(Data),
	Efs = meshtools:faces_to_e3dfaces(Fs),
	Mesh = #e3d_mesh{type=polygon,vs=Vs,fs=Efs},
	Obj = #e3d_object{name="SLP object",obj=Mesh},
	{ok, #e3d_file{objs=[Obj]}}.

read_slp(Data) ->
	GetFloats = fun(F) -> {Val,_} = string:to_float(F), Val end,
	LinesList1 = binary_to_list(Data),
	LinesList2 = string:tokens(LinesList1, "\r\n "),
	LinesList3 = lists:map(GetFloats, LinesList2),
	LinesList4 = lists:filter({erlang,is_float}, LinesList3),
	[_,_,_|LinesList5] = LinesList4,
	RawTriangles = group_verts(LinesList5),
	meshtools:raw_to_indexed(RawTriangles).

group_verts([]) -> [];
group_verts(Seq) ->
	[_,_,_,_,_,_,_,_,_,A,B,C,D,E,F,G,H,I|Tail] = Seq,
	[[{A,B,C},{D,E,F},{G,H,I}] | group_verts(Tail)].

% ============
% === Misc ===
% ============
print_boxed(String) ->
	A = length(String),
	io:fwrite("\n", []),
	io:fwrite("+-~s-+\n", [lists:duplicate(A, "-")]),
	io:fwrite("| ~s |\n", [String]),
	io:fwrite("+-~s-+\n", [lists:duplicate(A, "-")]).

% p(L) -> io:fwrite("~p\n", [L]).
% w(L) -> io:fwrite("~w\n", [L]).
