%% RAW Plugin
%% Import/Export ASCII Raw Triangle File Format (*.raw)
%% Copyright (c) 2005 Anthony D'Agostino (scorpius@netzero.com)
%%
%% For updates and other plugins:
%% http://chronosphere.home.comcast.net

-module(wpc_raw).
-export([init/0, menu/2, command/2]).
-include("e3d.hrl").

init() ->
    true.

menu({file, import}, Menu) ->
	menu_entry(Menu);
menu({file, export}, Menu) ->
	menu_entry(Menu);
menu({file, export_selected}, Menu) ->
    menu_entry(Menu);
menu(_, Menu) -> Menu.

command({file, {import, raw}}, St) ->
	Props = props(),
	wpa:import(Props, fun raw_import/1, St);
command({file, {export, raw}}, St) ->
	Props = props(),
	wpa:export(Props, fun export/2, St);
command({file, {export_selected, raw}}, St) ->
    Props = props(),
    wpa:export_selected(Props, fun export/2, St);
command(_, _) -> next.

menu_entry(Menu) ->
	Menu ++ [{"Raw Triangle (.raw)...", raw}].

props() ->
	[{ext, ".raw"},{ext_desc, "Raw Triangle ASCII File"}].

% ===========================
% === Raw Triangle Export ===
% ===========================
export(FileName, Contents) ->
	save_state(Contents),
	RAW = make_raw(Contents),
	file:write_file(FileName, RAW).

save_state(St) ->
	Bin = term_to_binary(St),
	ok = file:write_file("c:/Data/erlang-code/my-plugins/wings_state.dat", Bin).

make_raw(Contents) ->
	#e3d_file{objs=Objs} = Contents,
	%io:fwrite("Number of Objects: ~p\n", [length(Objs)]),
	%io:fwrite("~P\n", [Contents, 120]),
	%io:fwrite("~P\n", [Objs, 120]),
	CombinedObj = combine_objs(Objs),
	RawBody = make_body(CombinedObj),
	RawBody.

combine_objs(Objs) ->
	VFs = [get_vf_lists(Obj) || Obj <- Objs],
	{AllVs,AllFs} = lists:unzip(VFs),
	Nvs = lists:map({erlang,length}, AllVs),
	Incs = get_incs(Nvs),
	Vs = lists:append(AllVs),
	Fs = lists:append(reindex_faces(Incs, AllFs)),
	{Vs,Fs}.

get_incs(L) ->
	A = lists:reverse(L),
	B = make_incs(A),
	lists:reverse(B).

make_incs([]) -> [];
make_incs(L) ->
	[_|T] = L,
	[lists:sum(T) | make_incs(T)].

get_vf_lists(Obj) ->
	#e3d_object{obj=Mesh} = Obj,
	#e3d_mesh{vs=Vs,fs=Fs} = e3d_mesh:triangulate(Mesh),
	{Vs, e3dfaces_to_faces(Fs)}.

reindex_faces([], []) -> [];
reindex_faces(Incs, AllFs) ->
	Add = fun(X) -> fun(Y) -> X+Y end end,
	[Inc|RestIncs] = Incs,
	[Fs|RestFs] = AllFs,
	[[lists:map(Add(Inc), F) || F<-Fs] | reindex_faces(RestIncs, RestFs)].

make_body({Vs, Fs}) ->
	RawTriangles = meshtools:indexed_to_raw(Vs, Fs),
	raw_triangles_to_bin(RawTriangles).

raw_triangles_to_bin(RawTriangles) ->
	VertToBinary = fun(Vertex) ->
		{X,Y,Z} = Vertex,
		XA = list_to_binary(float_to_list(X)),
		YA = list_to_binary(float_to_list(Y)),
		ZA = list_to_binary(float_to_list(Z)),
		%p({X,XA}),
		%<<X:32/float-little, -Z:32/float-little, Y:32/float-little>> end,
		[XA, <<" ">>, YA, <<" ">>, ZA, <<" ">>] end,
	TriToBinary = fun(Triangle) ->
		FaceVerts = lists:map(VertToBinary, Triangle),
		[FaceVerts, <<"\n">>] end,
	lists:map(TriToBinary, RawTriangles).

e3dfaces_to_faces(E3dFaces) ->
	[FaceVs || #e3d_face{vs=FaceVs} <- E3dFaces].

% e3dfaces_to_faces(E3dFaces) ->
%	  GetFaceIndices = fun(E3dFace) ->
%		  #e3d_face{vs=FaceVs} = E3dFace,
%		  FaceVs end,
%	  lists:map(GetFaceIndices, E3dFaces).

% ===========================
% === Raw Triangle Import ===
% ===========================
raw_import(Name) ->
	case file:read_file(Name) of
	{ok,Bin} ->
		print_boxed("FileName: " ++ Name),
		Res = import(Bin),
		Res;
	{error,Reason} ->
		{error,file:format_error(Reason)}
	end.

import(Data) ->
	{Vs,Fs} = read_raw(Data),
	Efs = meshtools:faces_to_e3dfaces(Fs),
	Mesh = #e3d_mesh{type=polygon,vs=Vs,fs=Efs},
	Obj = #e3d_object{name="RAW object",obj=Mesh},
	{ok, #e3d_file{objs=[Obj]}}.

read_raw(Data) ->
	EOLs = "\r\n",  % common EOL characters [10,13]
	SPCs = "\t ,",  % common spacing characters [9,32,44]
	GroupVerts = fun(Seq) ->
		[A,B,C,D,E,F,G,H,I|_] = Seq,
		[{A,B,C},{D,E,F},{G,H,I}]
		end,
	LinesList1 = binary_to_list(Data),
	LinesList2 = string:tokens(LinesList1, EOLs),
	LinesList3 = [string:tokens(Line, SPCs) || Line <- LinesList2],
	LinesList4 = [lists:map({erlang,list_to_float}, Line) || Line <- LinesList3],
	RawTriangles = lists:map(GroupVerts, LinesList4),
	meshtools:raw_to_indexed(RawTriangles).

% ============
% === Misc ===
% ============
print_boxed(String) ->
	A = length(String),
	io:fwrite("\n", []),
	io:fwrite("+-~s-+\n", [lists:duplicate(A, "-")]),
	io:fwrite("| ~s |\n", [String]),
	io:fwrite("+-~s-+\n", [lists:duplicate(A, "-")]).

%p(Item) -> io:fwrite("~p\n", [Item]).
%w(Item) -> io:fwrite("~w\n", [Item]).
