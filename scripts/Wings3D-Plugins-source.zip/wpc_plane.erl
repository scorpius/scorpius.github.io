%% Plane Plugin
%% Includes four classic types of planes.
%% Copyright (c) 2002 Anthony D'Agostino (scorpius@netzero.com)
%%
%% For updates and other plugins:
%% http://chronosphere.home.comcast.net

-module(wpc_plane).
-export([init/0,menu/2,command/2]).

-import(math, [sqrt/1,cos/1,sin/1,pi/0,pow/2,exp/1]).

init() -> true.

menu({shape,more}, []) ->
	plane_menu();
menu({shape,more}, Menu) ->
	Menu ++ [separator|plane_menu()];
menu(_, Menu) -> Menu.

plane_menu() ->
	[{"Plane",plane,[option]},
	 {"Lumpy Plane",lumpyplane,[option]},
	 {"Wavy Plane",wavyplane,[option]},
	 {"Sombrero Plane",sombreroplane,[option]}].

command({shape,{more,{plane 		,Ask}}},_St) -> make_plane(Ask);
command({shape,{more,{lumpyplane	,Ask}}},_St) -> make_lumpyplane(Ask);
command({shape,{more,{wavyplane 	,Ask}}},_St) -> make_wavyplane(Ask);
command({shape,{more,{sombreroplane ,Ask}}},_St) -> make_sombreroplane(Ask);
command(_, _) -> next.

%%% The rest are local functions.

% ======= Regular Plane =======
make_plane(Ask) when is_atom(Ask) ->
	wpa:ask(Ask, "Create Regular Plane",
		[{"Resolution",7},
		 {"Size",2.0},
		 {"Thickness", 0.1}],
		fun(Res) -> {shape,{more,{plane,Res}}} end);
make_plane([Nres, Size, Thickness]) ->
	Vs = plane_verts(Nres, Size, +Thickness/2) ++
		 plane_verts(Nres, Size, -Thickness/2),
	Fs = plane_faces(Nres, Nres),
	{new_shape,"Plane",Fs,Vs}.

% ======= Lumpy Plane =======
make_lumpyplane(Ask) when is_atom(Ask) ->
	wpa:ask(Ask, "Create Lumpy Plane",
		[{"Resolution",30},
		 {"Size",2.0},
		 {"Lumps",2},
		 {"Thickness", 0.1}],
		fun(Res) -> {shape,{more,{lumpyplane,Res}}} end);
make_lumpyplane([Nres, Size, Lumps, Thickness]) ->
	Vs = lumpyplane_verts(Nres, Size, Lumps, +Thickness/2) ++
		 lumpyplane_verts(Nres, Size, Lumps, -Thickness/2),
	Fs = plane_faces(Nres, Nres),
	{new_shape,"Lumpy Plane",Fs,Vs}.

% ======= Wavy Plane =======
make_wavyplane(Ask) when is_atom(Ask) ->
	wpa:ask(Ask, "Make Wavy Plane",
		[{"Resolution",60},
		 {"Size",2.0},
		 {"Waves",4},
		 {"Height", 0.2},
		 {"Thickness", 0.1}],
		fun(Res) -> {shape,{more,{wavyplane,Res}}} end);
make_wavyplane([Nres, Size, Waves, Height, Thickness]) ->
	Vs = wavyplane_verts(Nres, Size, Waves, Height, +Thickness/2) ++
		 wavyplane_verts(Nres, Size, Waves, Height, -Thickness/2),
	Fs = plane_faces(Nres, Nres),
	{new_shape,"Wavy Plane",Fs,Vs}.

% ======= Sombrero Plane =======
make_sombreroplane(Ask) when is_atom(Ask) ->
	wpa:ask(Ask, "Make Sombrero Plane",
		[{"Resolution",60},
		 {"Size",2.0},
		 {"Waves",4},
		 {"Falloff",1},
		 {"Height", 1},
		 {"Thickness", 0.1}],
		fun(Res) -> {shape,{more,{sombreroplane,Res}}} end);
make_sombreroplane([Nres, Size, Waves, Falloff, Height, Thickness]) ->
	Vs = sombreroplane_verts(Nres, Size, Waves, Falloff, Height, +Thickness/2) ++
		 sombreroplane_verts(Nres, Size, Waves, Falloff, Height, -Thickness/2),
	Fs = plane_faces(Nres, Nres),
	{new_shape,"Sombrero Plane",Fs,Vs}.

plane_verts(Nres, Size, Thickness) ->
	Verts = [
			{
			Size*(I/(Nres-1.0)*2-1),
			Thickness,
			Size*(J/(Nres-1.0)*2-1)
			} % this tuple contains the x,y,z coordinates of this vertex
			|| I <- lists:seq(0, Nres-1), J <- lists:seq(0, Nres-1)],
			Verts.

lumpyplane_verts(Nres, Size, Lumps, Thickness) ->
	Verts = [
			{
			Size*(I/(Nres-1.0)*2-1),
			(Size*(cos(Lumps*(I/(Nres-1.0)*2-1)*pi())*
				   cos(Lumps*(J/(Nres-1.0)*2-1)*pi())/(Lumps*3)))+Thickness,
			Size*(J/(Nres-1.0)*2-1)
			} % this tuple contains the x,y,z coordinates of this vertex
			|| I <- lists:seq(0, Nres-1), J <- lists:seq(0, Nres-1)],
			Verts.

wavyplane_verts(Nres, Size, Waves, Height, Thickness) ->
	Verts = [
			{
			Size*(I/(Nres-1.0)*2-1),
			(Size*(1.0/Waves *
				  cos(2*pi()*sqrt( pow((Waves*(I/(Nres-1.0)*2-1)), 2)
								 + pow((Waves*(J/(Nres-1.0)*2-1)), 2))))*Height)+Thickness,
			Size*(J/(Nres-1.0)*2-1)
			} % this tuple contains the x,y,z coordinates of this vertex
			|| I <- lists:seq(0, Nres-1), J <- lists:seq(0, Nres-1)],
			Verts.

sombreroplane_verts(Nres, Size, Waves, Falloff, Height, Thickness) ->
	Verts = [
			{
			Size*(I/(Nres-1.0)*2-1),
			(Size*(1.0/Waves *
				  cos(2*pi()*sqrt( pow((Waves*(I/(Nres-1.0)*2-1)), 2)
								  +pow((Waves*(J/(Nres-1.0)*2-1)), 2)))
					  * exp(-sqrt( pow((Waves*(I/(Nres-1.0)*2-1)), 2)
								  +pow((Waves*(J/(Nres-1.0)*2-1)), 2))*Falloff))*Height)+Thickness,
			Size*(J/(Nres-1.0)*2-1)
			} % this tuple contains the x,y,z coordinates of this vertex
			|| I <- lists:seq(0, Nres-1), J <- lists:seq(0, Nres-1)],
			Verts.


plane_faces_top(Ures, Vres) ->
	Faces = [ [I*Vres+J, I*Vres+J+1, (I+1)*Vres+J+1, (I+1)*Vres+J]
			% this list contains the list of vertex indices in this face.
			|| I <- lists:seq(0, Vres-2), J <- lists:seq(0, Ures-2)],
			Faces.

plane_faces_bot(Ures, Vres) ->
	Offset = Ures*Vres,
	Faces = [
			[
			Offset + ((I+1)*Vres+J),
			Offset + ((I+1)*Vres+J+1),
			Offset + (I*Vres+J+1),
			Offset + (I*Vres+J)
			] % this list contains the list of vertex indices
			  % in this face (a quad)
			|| I <- lists:seq(0, Vres-2), J <- lists:seq(0, Ures-2)],
			Faces.

plane_faces_left(Ures, Vres) ->
	A = lists:seq(0, Vres-1),
	B = lists:map(fun(X) -> X+(Ures*Vres) end, A),
	Faces = lists:reverse(A) ++ B,
	[Faces].

plane_faces_back(Ures, Vres) ->
	A = lists:seq(Vres-1, Ures*Vres-1, Vres),
	B = lists:map(fun(X) -> X+(Ures*Vres) end, A),
	Faces = lists:reverse(A) ++ B,
	[Faces].

plane_faces_right(Ures, Vres) ->
	A = lists:seq(Ures*Vres-1, Ures*Vres-Vres, -1),
	B = lists:map(fun(X) -> X+(Ures*Vres) end, A),
	Faces = lists:reverse(A) ++ B,
	[Faces].

plane_faces_front(Ures, Vres) ->
	A = lists:seq(Ures*Vres-Vres, 0, -Vres),
	B = lists:map(fun(X) -> X+(Ures*Vres) end, A),
	Faces = lists:reverse(A, B),
	[Faces].

plane_faces(Nres, Nres) ->
	plane_faces_top(Nres, Nres) ++
	plane_faces_bot(Nres, Nres) ++
	plane_faces_left(Nres, Nres) ++
	plane_faces_right(Nres, Nres) ++
	plane_faces_front(Nres, Nres) ++
	plane_faces_back(Nres, Nres).

