# +---------------------------------------------------------+
# | Copyright (c) 2002 Anthony D'Agostino                   |
# | http://www.redrival.com/scorpius                        |
# | scorpius@netzero.com                                    |
# | February 3, 2001                                        |
# | Radiosity Import Export Suite v0.5                      |
# +---------------------------------------------------------+
# | Read and write Object File Format (*.off)               |
# | Exports the selected mesh only.                         |
# | Note: Can also be used from the command line to dump    |
# | the file contents.                                      |
# +---------------------------------------------------------+

import os, time
import meshtools

# =============================
# ====== Read OFF Format ======
# =============================
def read(filename):
	start = time.clock()
	file = open(filename, "rb")

	verts = []
	faces = []

	# === OFF Header ===
	offheader = file.readline()
	numverts, numfaces, null = file.readline().split()
	numverts = int(numverts)
	numfaces = int(numfaces)

	# === Vertex List ===
	for i in range(numverts):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/numverts, "Reading Verts")
		x, y, z = file.readline().split()
		x, y, z = float(x), float(y), float(z)
		verts.append((x, y, z))

	# === Face List ===
	for i in range(numfaces):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/numfaces, "Reading Faces")
		line = file.readline().split()
		numfaceverts = len(line)-1
		facev = []
		for j in range(numfaceverts):
			index = int(line[j+1])
			facev.append(index)
		facev.reverse()
		faces.append(facev)

	objname = os.path.splitext(os.path.basename(filename))[0]

	meshtools.create_mesh(verts, faces, objname)
	Blender.Window.RedrawAll()
	meshtools.Draw_Progress_Bar(1.0, '')  # clear progressbar
	file.close()
	end = time.clock()
	seconds = " in %.2f %s" % (end-start, "seconds")
	message = "Successfully imported " + os.path.basename(filename) + seconds
	meshtools.print_boxed(message)

# ==============================
# ====== Write OFF Format ======
# ==============================
def write(filename):
	start = time.clock()
	file = open(filename, "wb")

	object = Blender.Object.GetSelected()
	objname = object[0].name
	meshname = object[0].data.name
	mesh = Blender.NMesh.GetRaw(meshname)
	#mesh = Blender.NMesh.GetRawFromObject(meshname)	# for SubSurf
	obj = Blender.Object.Get(objname)

	# === OFF Header ===
	file.write("OFF\n")
	file.write("%d %d %d\n" % (len(mesh.verts), len(mesh.faces), 0))

	# === Vertex List ===
	for i in range(len(mesh.verts)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(mesh.verts), "Writing Verts")
		x, y, z = mesh.verts[i].co
		file.write("%f %f %f\n" % (x, y, z))

	# === Face List ===
	for i in range(len(mesh.faces)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(mesh.faces), "Writing Faces")
		file.write(`len(mesh.faces[i].v)`+' ')
		mesh.faces[i].v.reverse()
		for j in range(len(mesh.faces[i].v)):
			file.write(`mesh.faces[i].v[j].index`+' ')
		file.write("\n")


	meshtools.Draw_Progress_Bar(1.0, '')  # clear progressbar
	file.close()
	end = time.clock()
	seconds = " in %.2f %s" % (end-start, "seconds")
	message = "Successfully exported " + os.path.basename(filename) + seconds
	meshtools.print_boxed(message)

# ============
# === Main ===
# ============
if __name__ == "__main__":
	import sys

	if len(sys.argv) == 1: # if no arguments are specified,
		print "              _________________________________________________ "
		print "                                                                "
		print "                    Copyright (c) 2002 Anthony D'Agostino       "
		print "              http://ourworld.compuserve.com/homepages/scorpius "
		print "                           scorpius@netzero.com              "
		print "                    Dump contents of *.off file format          "
		print "                            (First 22 items only)               "
		print "              _________________________________________________ "
		print "                                                                "
		print "                    Usage: python off.py filename.off           "
		sys.exit()

	filename = sys.argv[1]
	file = open(filename, "rb")


	# === OFF Header ===
	offheader = file.readline()
	numverts, numfaces, null = file.readline().split()

	print offheader, numverts, numfaces, null

	# === Vertex List ===
	for i in range(int(numverts)):
		x, y, z = file.readline().split()
		x, y, z = float(x), float(y), float(z)
		print x, y, z

	# === Face List ===
	for i in range(int(numfaces)):
		line = file.readline().split()
		print len(line)-1,
		for j in range(len(line)-1):
			print line[j+1],
		print


else:
	import Blender, meshtools
