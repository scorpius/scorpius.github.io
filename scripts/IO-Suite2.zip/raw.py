# +---------------------------------------------------------+
# | Copyright (c) 2002 Anthony D'Agostino                   |
# | http://www.redrival.com/scorpius                        |
# | scorpius@netzero.com                                    |
# | April 28, 2002                                          |
# | Radiosity Import Export Suite v0.5                      |
# +---------------------------------------------------------+
# | Read and write RAW Triangle File Format (*.raw)         |
# | Exports the selected mesh only.                         |
# | Note: Can also be used from the command line to dump    |
# | the file contents.                                      |
# +---------------------------------------------------------+

import os, sys, time
import meshtools

# ================================
# === Read RAW Triangle Format ===
# ================================
def read(filename):
	start = time.clock()
	file = open(filename, "rb")

	# Collect data from RAW format
	faces = []
	for line in file.readlines():
		try:
			f1, f2, f3, f4, f5, f6, f7, f8, f9 = map(float, line.split())
			faces.append([(f1, f2, f3), (f4, f5, f6), (f7, f8, f9)])
		except: # Quad
			f1, f2, f3, f4, f5, f6, f7, f8, f9, A, B, C = map(float, line.split())
			faces.append([(f1, f2, f3), (f4, f5, f6), (f7, f8, f9), (A, B, C)])

	# Generate verts and faces lists, without duplicates
	verts = []
	coords = {}
	index = 0
	for i in range(len(faces)):
		for j in range(len(faces[i])):
			vertex = faces[i][j]
			if not coords.has_key(vertex):
				coords[vertex] = index
				index += 1
				verts.append(vertex)
			faces[i][j] = coords[vertex]

	objname = os.path.splitext(os.path.basename(filename))[0]

	meshtools.create_mesh(verts, faces, objname)
	Blender.Window.RedrawAll()
	meshtools.Draw_Progress_Bar(1.0, '')  # clear progressbar
	file.close()
	end = time.clock()
	seconds = " in %.2f %s" % (end-start, "seconds")
	message = "Successfully imported " + os.path.basename(filename) + seconds
	meshtools.print_boxed(message)

# =================================
# === Write RAW Triangle Format ===
# =================================
def write(filename):
	start = time.clock()
	file = open(filename, "wb")

	objects = Blender.Object.GetSelected()
	objname = objects[0].name
	meshname = objects[0].data.name
	mesh = Blender.NMesh.GetRaw(meshname)
	obj = Blender.Object.Get(objname)


	std=sys.stdout
	sys.stdout=file
	for face in mesh.faces:
		if len(face.v) == 3:		# triangle
			v1, v2, v3 = face.v
			faceverts = tuple(v1.co) + tuple(v2.co) + tuple(v3.co)
			print "% f % f % f % f % f % f % f % f % f" % faceverts
		else:						# quadrilateral
			v1, v2, v3, v4 = face.v
			faceverts1 = tuple(v1.co) + tuple(v2.co) + tuple(v3.co)
			faceverts2 = tuple(v3.co) + tuple(v4.co) + tuple(v1.co)
			print "% f % f % f % f % f % f % f % f % f" % faceverts1
			print "% f % f % f % f % f % f % f % f % f" % faceverts2
	sys.stdout=std


	meshtools.Draw_Progress_Bar(1.0, '')  # clear progressbar
	file.close()
	end = time.clock()
	seconds = " in %.2f %s" % (end-start, "seconds")
	message = "Successfully exported " + os.path.basename(filename) + seconds
	meshtools.print_boxed(message)

# ============
# === Main ===
# ============
if __name__ == "__main__":
	import sys

	if len(sys.argv) == 1: # if no arguments are specified,
		print "              _________________________________________________ "
		print "                                                                "
		print "                    Copyright (c) 2002 Anthony D'Agostino       "
		print "              http://ourworld.compuserve.com/homepages/scorpius "
		print "                           scorpius@netzero.com              "
		print "                        Raw Triangle to Videoscape OBJ          "
		print "              _________________________________________________ "
		print "                                                                "
		print "                Usage: python raw.py filename.raw > sphere.obj  "
		sys.exit()

	filename = sys.argv[1]
	file = open(filename, "rb")
	lines = file.readlines()

	# Collect data from RAW format
	faces = []
	for line in lines:
		f1, f2, f3, f4, f5, f6, f7, f8, f9 = map(float, line.split())
		faces.append([(f1, f2, f3), (f4, f5, f6), (f7, f8, f9)])

	# Generate verts and faces lists, without duplicates
	verts = []
	coords = {}
	index = 0
	for i in range(len(faces)):
		for j in range(3):
			vertex = faces[i][j]
			if not coords.has_key(vertex):
				coords[vertex] = index
				index += 1
				verts.append(vertex)
			faces[i][j] = coords[vertex]


	# === Videoscape Header ===
	print "3DG1"
	print "%d" % len(verts)

	# === Vertex List ===
	for vertex in verts:
		print "% f % f % f" % vertex

	# === Face List ===
	for face in faces:
		print 3,
		for index in face:
			print index,
		print '0xFFB299'

else:
	import Blender, meshtools
