# +---------------------------------------------------------+
# | Copyright (c) 2002 Anthony D'Agostino                   |
# | http://www.redrival.com/scorpius                        |
# | scorpius@netzero.com                                    |
# | April 11, 2002                                          |
# | Radiosity Import Export Suite v0.5                      |
# +---------------------------------------------------------+
# | Read and write Radiosity File Format (*.radio)          |
# | Exports the selected mesh only.                         |
# | Note: Can also be used from the command line to dump    |
# | the file contents.                                      |
# +---------------------------------------------------------+

import struct, os, time

# ===============================
# ====== Read Radio Format ======
# ===============================
def read(filename):
	start = time.clock()
	file = open(filename, "rb")
	mesh = Blender.NMesh.GetRaw()

	# === Object Name ===
	namelen, = struct.unpack("<h",  file.read(2))
	objname, = struct.unpack("<"+`namelen`+"s", file.read(namelen))

	# === Vertex List ===
	numverts, = struct.unpack("<l", file.read(4))
	for i in range(numverts):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/numverts, "Reading Verts")
		x, y, z = struct.unpack("<fff", file.read(12))
		mesh.verts.append(Blender.NMesh.Vert(x, y, z))

	# === Face List ===
	numfaces, = struct.unpack("<l", file.read(4))
	for i in range(numfaces):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/numfaces, "Reading Faces")

		face = Blender.NMesh.Face()
		numfaceverts, = struct.unpack("<b", file.read(1))

		for j in range(numfaceverts):
			index, = struct.unpack("<h", file.read(2))
			face.v.append(mesh.verts[index])

		for j in range(4):
			r, g, b, a = struct.unpack("<BBBB", file.read(4))
			vertexcolor = Blender.NMesh.Col(r, g, b, a)
			face.col.append(vertexcolor)

		if len(face.v) == 3:
			face.uv = [ (0,0), (0,1), (1,1) ]
		else:
			face.uv = [ (0,0), (0,1), (1,1), (1,0) ]

		face.mode = 0
		mesh.faces.append(face)

	# ->tools.create_mesh(verts, faces, objname):
	Blender.NMesh.PutRaw(mesh, objname)
	object = Blender.Object.GetSelected()
	object[0].name=objname
	# ->tools.create_mesh(verts, faces, objname):

	Blender.Window.RedrawAll()
	meshtools.Draw_Progress_Bar(1.0, '')  # clear progressbar
	file.close()
	end = time.clock()
	seconds = " in %.2f %s" % (end-start, "seconds")
	message = "Successfully imported " + os.path.basename(filename) + seconds
	meshtools.print_boxed(message)

# ================================
# ====== Write Radio Format ======
# ================================
def write(filename):
	start = time.clock()
	file = open(filename, "wb")

	object = Blender.Object.GetSelected()
	objname = object[0].name
	meshname = object[0].data.name
	mesh = Blender.NMesh.GetRaw(meshname)
	obj = Blender.Object.Get(objname)

	if mesh.has_col == 0:
		print "Please assign vertex colors before exporting.",
		print objname, "was not saved."
		return

	# === Object Name ===
	file.write(struct.pack("<h", len(objname)))
	file.write(struct.pack("<"+`len(objname)`+"s", objname))

	# === Vertex List ===
	file.write(struct.pack("<l", len(mesh.verts)))
	for i in range(len(mesh.verts)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(mesh.verts), "Writing Verts")

		x, y, z = mesh.verts[i].co
		file.write(struct.pack("<fff", x, y, z))

	# === Face List ===
	file.write(struct.pack("<l", len(mesh.faces)))
	for i in range(len(mesh.faces)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(mesh.faces), "Writing Faces")

		file.write(struct.pack("<b", len(mesh.faces[i].v)))
		for j in range(len(mesh.faces[i].v)):
			file.write(struct.pack("<h", mesh.faces[i].v[j].index))

		for j in range(4): # .col always has a length of 4
			file.write(struct.pack("<BBBB", mesh.faces[i].col[j].r,
											mesh.faces[i].col[j].g,
											mesh.faces[i].col[j].b,
											mesh.faces[i].col[j].a))

	meshtools.Draw_Progress_Bar(1.0, '')  # clear progressbar
	file.close()
	end = time.clock()
	seconds = " in %.2f %s" % (end-start, "seconds")
	message = "Successfully exported " + os.path.basename(filename) + seconds
	meshtools.print_boxed(message)

# ============
# === Main ===
# ============
if __name__ == "__main__":
	import sys

	if len(sys.argv) == 1: # if no arguments are specified,
		print "              _________________________________________________ "
		print "                                                                "
		print "                    Copyright (c) 2002 Anthony D'Agostino       "
		print "              http://ourworld.compuserve.com/homepages/scorpius "
		print "                           scorpius@netzero.com              "
		print "                    Dump contents of *.radio file format        "
		print "                            (First 22 items only)               "
		print "              _________________________________________________ "
		print "                                                                "
		print "                 Usage: python radiosity.py filename.radio      "
		sys.exit()

	maxprint = 22

	filename = sys.argv[1]
	file = open(filename, "rb")

	# === Object Name ===
	namelen, = struct.unpack("<h",  file.read(2))
	objname, = struct.unpack("<"+`namelen`+"s", file.read(namelen))
	print "Name :", objname

	# === Vertex List ===
	numverts, = struct.unpack("<l", file.read(4))
	print "Verts:", numverts
	for i in range(numverts):
		x, y, z = struct.unpack("fff", file.read(12))
		if i < maxprint: print "% f % f % f " % (x, y, z)

	# === Face List ===
	numfaces, = struct.unpack("<l", file.read(4))
	print "Faces:", numfaces
	for i in range(numfaces):
		numfaceverts, = struct.unpack("b", file.read(1))
		if i < maxprint: print numfaceverts,
		for j in range(numfaceverts):
			index, = struct.unpack("h", file.read(2))
			#print "%4d" % index,

		for j in range(4):
			r, g, b, a = struct.unpack("BBBB", file.read(4))
			if i < maxprint: print "[%3d %3d %3d %3d]" % (r,g,b,a),
		if i < maxprint: print
else:
	import Blender, meshtools
