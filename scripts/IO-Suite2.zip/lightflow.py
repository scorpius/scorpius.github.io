# +---------------------------------------------------------+
# | Copyright (c) 2002 Anthony D'Agostino                   |
# | http://www.redrival.com/scorpius                        |
# | scorpius@netzero.com                                    |
# | October 13, 2002                                        |
# | Radiosity Import Export Suite v0.5                      |
# +---------------------------------------------------------+
# | Read and write LightFlow Mesh File Format (*.mesh)      |
# | Exports the selected mesh only.                         |
# | Note: Can also be used from the command line to dump    |
# | the file contents.                                      |
# +---------------------------------------------------------+

import struct, os, sys, time

# ====================================
# === Read A List Of 3-Item Tuples ===
# ====================================
def read_vector3array(file, num):
	vectors = []
	for i in range(num):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/num, "Reading Vector 3 Array")
		vectors.append(struct.unpack("<fff", file.read(12)))
	return vectors

# ====================================
# === Read A List Of 2-Item Tuples ===
# ====================================
def read_vector2array(file, num):
	vectors = []
	for i in range(num):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/num, "Reading Vector 2 Array")
		vectors.append(struct.unpack("<ff", file.read(8)))
	return vectors

# ====================================
# === Read A List Of Long Integers ===
# ====================================
def read_intarray(file, num):
	#ints = []
	#for i in range(num):
	#	 ints.append(struct.unpack("<l", file.read(4))[0])
	#	 if not i%100 and meshtools.show_progress:
	#		 meshtools.Draw_Progress_Bar(float(i)/num, "Reading Integer Array")
	#return ints
	return struct.unpack("<" + `num` + "l", file.read(4*num))

# =======================================
# === Read LightFlow Mesh File Format ===
# =======================================
def read(filename):
	start = time.clock()
	file = open(filename, "rb")

	num_objs, = struct.unpack("<l", file.read(4))

	numverts, = struct.unpack("<l", file.read(4))
	numnorms, = struct.unpack("<l", file.read(4))
	numuvcos, = struct.unpack("<l", file.read(4))
	numfaces, = struct.unpack("<l", file.read(4))
	numtotal, = struct.unpack("<l", file.read(4))
	verts = read_vector3array(file, numverts)
	norms = read_vector3array(file, numnorms)
	uvcos = read_vector2array(file, numuvcos)
	nv = read_intarray(file, numfaces)
	fp = read_intarray(file, numtotal)
	fn = read_intarray(file, numtotal)
	ft = read_intarray(file, numtotal)

	# Generate The Face List
	a = 0
	faces = []				   ; facesuv = []
	for i in range(len(nv)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(nv), "Generating The Face List")
		numfaceverts = nv[i]
		facev = []			   ; faceuv = []
		for j in range(numfaceverts):
			index, uvidx = fp[a], ft[a]
			facev.append(index); faceuv.append(uvidx)
			a += 1
		faces.append(facev)    ; facesuv.append(faceuv)

	objname = os.path.splitext(os.path.basename(filename))[0]

	meshtools.create_mesh(verts, faces, objname, facesuv, uvcos, norms)
	Blender.Window.RedrawAll()
	meshtools.Draw_Progress_Bar(1.0, '')  # clear progressbar
	file.close()
	end = time.clock()
	seconds = " in %.2f %s" % (end-start, "seconds")
	message = "Successfully imported " + os.path.basename(filename) + seconds
	meshtools.print_boxed(message)

# =====================================
# === Write A List Of 3-Item Tuples ===
# =====================================
def write_vector3array(file, xlist):
	for i in range(len(xlist)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(xlist), "Writing Vector 3 Array")
		x, y, z = xlist[i]
		file.write(struct.pack("<3f", x, y, z))

# =====================================
# === Write A List Of 2-Item Tuples ===
# =====================================
def write_vector2array(file, xlist):
	for i in range(len(xlist)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(xlist), "Writing Vector 2 Array")
		x, y = xlist[i]
		file.write(struct.pack("<2f", x, y))

# =====================================
# === Write A List Of Long Integers ===
# =====================================
def write_intarray(file, xlist):
	for i in range(len(xlist)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(xlist), "Writing Integer Array")
		file.write(struct.pack("<l", xlist[i]))

#	 file.write(*struct.pack("<" + `int(len(xlist))` + "l", xlist))   # ?? no

#	 long2str = lambda idx: struct.unpack("<", idx)
#	 file.writelines(map(long2str, xlist))

# ============================
# === Generate Vertex List ===
# ============================
def generate_verts(mesh):
	verts = []
	for i in range(len(mesh.verts)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(mesh.verts), "Generate Vertex List")
		x, y, z = mesh.verts[i].co
		verts.append((x, y, z))
	return verts

# ===================================
# === Generate Vertex Normal List ===
# ===================================
def generate_norms(mesh):
	norms = []
	for i in range(len(mesh.verts)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(mesh.verts), "Generate Vertex Normals")
		x, y, z = mesh.verts[i].no
		norms.append((x, y, z))
	return norms

# ===============================
# === Generate UV Coords List ===
# ===============================
def generate_uvcos(mesh):
	if not mesh.hasFaceUV():
		return [(0,0)], {(0,0): 0}

	# collect, remove duplicates, add indices, and write the uv list
	uvcos = []
	uvcoords = {}
	uvidx = 0
	for i in range(len(mesh.faces)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(mesh.faces), "Generate UV Coords List")
		numfaceverts = len(mesh.faces[i].v)
		for j in range(numfaceverts-1, -1, -1): 	# Reverse order
			u,v = mesh.faces[i].uv[j]
			if not uvcoords.has_key((u,v)):
				uvcoords[(u,v)] = uvidx
				uvidx += 1
				uvcos.append((u,v))

	print "Number of uvcos   :", len(uvcos)
	print "Number of uvcoords:", len(uvcoords)
	return uvcos, uvcoords

# ========================
# === Generate nv List ===
# ========================
def generate_nv(mesh):
	nv = []
	for face in mesh.faces: nv.append(len(face.v))
	return nv

# =============================
# === Generate fp & ft List ===
# =============================
def generate_fpft(mesh, uvcoords):
	fp = []
	ft = []
	for i in range(len(mesh.faces)):
		if not i%100 and meshtools.show_progress:
			meshtools.Draw_Progress_Bar(float(i)/len(mesh.faces), "Generate Points & Textures")
		numfaceverts = len(mesh.faces[i].v)
		for j in range(numfaceverts):
			index = mesh.faces[i].v[j].index
			if mesh.hasFaceUV():
				uv = mesh.faces[i].uv[j]
				uvidx = uvcoords[uv]
			else:
				uvidx = 0
			fp.append(index)
			ft.append(uvidx)
	return fp, ft

# ========================================
# === Write LightFlow Mesh File Format ===
# ========================================
def write(filename):
	import operator

	start = time.clock()
	file = open(filename, "wb")

	objects = Blender.Object.GetSelected()
	objname = objects[0].name
	meshname = objects[0].data.name
	mesh = Blender.NMesh.GetRaw(meshname)
	obj = Blender.Object.Get(objname)

	verts = generate_verts(mesh)
	norms = generate_norms(mesh)
	uvcos, uvcoords = generate_uvcos(mesh)
	nv = generate_nv(mesh)
	fp, ft = generate_fpft(mesh, uvcoords)
	fn = fp # always identical?
	nvtot = reduce(operator.add, nv)

	file.write(struct.pack("<l", len(objects)))
	file.write(struct.pack("<l", len(verts)))
	file.write(struct.pack("<l", len(norms)))
	file.write(struct.pack("<l", len(uvcos)))
	file.write(struct.pack("<l", len(nv)))
	file.write(struct.pack("<l", nvtot))

	write_vector3array(file, verts)
	write_vector3array(file, norms)
	write_vector2array(file, uvcos)
	write_intarray(file, nv)
	write_intarray(file, fp)
	write_intarray(file, fn)
	write_intarray(file, ft)

	meshtools.Draw_Progress_Bar(1.0, '')  # clear progressbar
	file.close()
	end = time.clock()
	seconds = " in %.2f %s" % (end-start, "seconds")
	message = "Successfully exported " + os.path.basename(filename) + seconds
	meshtools.print_boxed(message)

# ============
# === Main ===
# ============
if __name__ == "__main__":
	import sys, meshtools

	if len(sys.argv) == 1: # if no arguments are specified,
		print "              _________________________________________________ "
		print "                                                                "
		print "                    Copyright (c) 2002 Anthony D'Agostino       "
		print "              http://ourworld.compuserve.com/homepages/scorpius "
		print "                           scorpius@netzero.com              "
		print "                        Raw Triangle to Videoscape OBJ          "
		print "              _________________________________________________ "
		print "                                                                "
		print "                Usage: python raw.py filename.raw > sphere.obj  "
		sys.exit()

	meshtools.show_progress = 0  # only used within Blender's environment

	filename = sys.argv[1]
	file = open(filename, "rb")

	num_objs, = struct.unpack("<l", file.read(4))

	numverts, = struct.unpack("<l", file.read(4))
	numnorms, = struct.unpack("<l", file.read(4))
	numuvcos, = struct.unpack("<l", file.read(4))
	numfaces, = struct.unpack("<l", file.read(4))
	numtotal, = struct.unpack("<l", file.read(4))
	verts = read_vector3array(file, numverts)
	norms = read_vector3array(file, numnorms)
	uvcos = read_vector2array(file, numuvcos)
	nv = read_intarray(file, numfaces)
	fp = read_intarray(file, numtotal)
	fn = read_intarray(file, numtotal)
	ft = read_intarray(file, numtotal)

	print "numverts:", numverts
	print "numnorms:", numnorms
	print "numuvcos:", numuvcos
	print "numfaces:", numfaces
	print "numtotal:", numtotal
	print
	print "verts:"
	for i in verts: print "% f % f % f" % tuple(i)
	print
	print "norms:"
	for i in norms: print "% f % f % f" % tuple(i)
	print
	print "uvcos:"
	for i in uvcos: print "% f % f" % tuple(i)
	print
	print "numtotal:\n", numtotal, "number of vertices of each face"
	print
	print "nv:\n", nv
	print
	print "fp:\n", fp
	print
	print "fn:\n", fn
	print
	print "ft:\n", ft

else:
	import Blender, meshtools



# keys = sys.modules.keys()
# keys.sort()
# maxkeylen = max(map(len, keys))
# for key in keys:
#	  print key.ljust(maxkeylen), sys.modules[key]
# print
# #print sys.modules.keys()   #['__main__']
# #print __main__.meshtools.show_progress
