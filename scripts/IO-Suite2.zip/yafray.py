# +---------------------------------------------------------+
# | Copyright (c) 2003 Anthony D'Agostino                   |
# | http://www.redrival.com/scorpius                        |
# | scorpius@netzero.com                                    |
# | February 18, 2003                                       |
# | Radiosity Import Export Suite v0.5                      |
# +---------------------------------------------------------+
# | Read and write Yafray XML Gzipped Meshes                |
# | Exports the selected mesh only.                         |
# | Note: Can also be used from the command line to dump    |
# | the file contents.                                      |
# +---------------------------------------------------------+

import os, time, gzip
import meshtools

# ==================
# === read_verts ===
# ==================
def read_verts(lines):
	verts = []
	for line in lines:
		line = line.strip()
		line = line.split(chr(34))
		if len(line) > 1 and line[0] == "<p x=":
			x, y, z = float(line[1]), float(line[3]), float(line[5])
			verts.append((x,y,z))
	return verts

# ==================
# === read_faces ===
# ==================
def read_faces(lines):
	faces = []
	for line in lines:
		line = line.strip()
		line = line.split(chr(34))
		if len(line) > 1 and line[0] == "<f a=":
			idx1, idx2, idx3 = int(line[1]), int(line[3]), int(line[5])
			faces.append((idx1, idx2, idx3))
	return faces

# ============
# === read ===
# ============
def read(filename):
	start = time.clock()
	file = gzip.GzipFile(filename)
	lines = file.readlines()

	verts = read_verts(lines)
	faces = read_faces(lines)
	objname = os.path.splitext(os.path.basename(filename))[0]

	meshtools.create_mesh(verts, faces, objname)
	Blender.Window.RedrawAll()
	meshtools.Draw_Progress_Bar(1.0, '')    # clear progressbar
	file.close()
	end = time.clock()
	seconds = " in %.2f %s" % (end-start, "seconds")
	message = "Successfully imported " + os.path.basename(filename) + seconds
	meshtools.print_boxed(message)

# ============
# === Main ===
# ============
if __name__ == "__main__":
	import sys, glob, operator, gzip

	if len(sys.argv) > 1:
		filenames = map(glob.glob, sys.argv[1:])	# must flatten
		filenames = reduce(operator.add, filenames) # flattened
	else:
		filenames = glob.glob("*.xml.gz")

	for filename in filenames:
		#print filename
		verts, faces, objname = read(filename)
		print verts
		print faces
		print objname

else:
	import Blender, meshtools
