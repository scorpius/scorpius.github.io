# +---------------------------------------------------------+
# | Copyright (c) 2002 Anthony D'Agostino                   |
# | http://www.redrival.com/scorpius                        |
# | scorpius@netzero.com                                    |
# | Feb 19, 2002                                            |
# | Radiosity Import Export Suite v0.5                      |
# +---------------------------------------------------------+
# | Read and write Wings3D File Format (*.wings)            |
# | Exports the selected mesh only.                         |
# | Note: Can also be used from the command line to dump    |
# | the file contents.                                      |
# +---------------------------------------------------------+

import struct, zlib, time, cStringIO, os, sys

# ==============================================
# === Read The 'Header' Common To All Chunks ===
# ==============================================
def read_chunkheader(data):
	data.read(2) #version, tag = struct.unpack(">BB", data.read(2))
	misc, namelen = struct.unpack(">BH", data.read(3))
	name = data.read(namelen)
	return name

# ==============================
# === Read The Material Mode ===
# ==============================
def read_mode(data):
	data.read(5)			# BL
	read_chunkheader(data)	# "mode"
	misc, namelen = struct.unpack(">BH", data.read(3))
	data.read(namelen)
	data.read(1)			# 6A

# =======================
# === Read Hard Edges ===
# =======================
def read_hardedges(data):
	tag = data.read(1)
	if tag == '\x6A':
		return # There are no hard edges
	elif tag == '\x6B':
		numhardedges, = struct.unpack(">H", data.read(2))
		print "numhardedges:", numhardedges
		for i in range(numhardedges):
			data.read(1)
	elif tag == '\x6C':
		numhardedges, = struct.unpack(">L", data.read(4))
		print "numhardedges:", numhardedges
		for i in range(numhardedges):
			misc = data.read(1)
			if misc == '\x61':    # next value is stored as a byte
				data.read(1)
			elif misc == '\x62':  # next value is stored as a long
				data.read(4)
		data.read(1) # 6A
	else:
		print tag

# ==================
# === Read Edges ===
# ==================
def read_edges(data):
	misc, numedges = struct.unpack(">BL", data.read(5))
	edge_table = {}  # the winged-edge table
	for i in range(numedges):
		if not i%100 and meshtools.show_progress: meshtools.Draw_Progress_Bar(float(i)/numedges, "Reading Edges")
		misc, etype = struct.unpack(">BL", data.read(5))
		if etype == 2:				# Vertex Colors
			data.read(10)			# or read_chunkheader(data)  # "color"
			data.read(5)			# BL
			r1,g1,b1,r2,g2,b2 = struct.unpack(">dddddd", data.read(48))
			#print "%3d %3d %3d | %3d %3d %3d" % (r1*255,g1*255,b1*255,r2*255,g2*255,b2*255),
			#print "%f %f %f | %f %f %f" % (r1, g1, b1, r2, g2, b2)
		data.read(9) # or read_chunkheader(data)  # "edge"
		edge = []			# the eight entries for this edge
		for e in range(8):	# Sv Ev | Lf Rf | Lp Ls | Rp Rs
			misc = data.read(1)
			if misc == '\x61':    # next value is stored as a byte
				entry, = struct.unpack(">B", data.read(1))
				edge.append(entry)
			elif misc == '\x62':  # next value is stored as a long
				entry, = struct.unpack(">L", data.read(4))
				edge.append(entry)
		edge_table[i] = edge
		data.read(1) # 6A
	data.read(1) # 6A
	return edge_table

# ==================
# === Read Faces ===
# ==================
def read_faces(data):
	misc, numfaces = struct.unpack(">BL", data.read(5))
	for i in range(numfaces):
		if not i%100 and meshtools.show_progress: meshtools.Draw_Progress_Bar(float(i)/numfaces, "Reading Faces")
		if data.read(1) == '\x6C':  # a material follows
			data.read(4)
			read_chunkheader(data)
			misc, namelen = struct.unpack(">BH", data.read(3))
			materialname = data.read(namelen)
			data.read(1)
	data.read(1) # 6A
	return numfaces

# ==================
# === Read Verts ===
# ==================
def read_verts(data):
	misc, numverts = struct.unpack(">BL", data.read(5))
	verts = []	# a list of verts
	for i in range(numverts):
		if not i%100 and meshtools.show_progress: meshtools.Draw_Progress_Bar(float(i)/numverts, "Reading Verts")
		data.read(10)
		x, y, z = struct.unpack(">ddd", data.read(24))  # double precision
		verts.append((x, -z, y))
		data.read(1) # 6A
	data.read(1) # 6A
	return verts

# =======================
# === Make Face Table ===
# =======================
def make_face_table(edge_table): # For Wings
	face_table = {}
	for i in range(len(edge_table)):
		Lf = edge_table[i][2]
		Rf = edge_table[i][3]
		face_table[Lf] = i
		face_table[Rf] = i
	return face_table

# =======================
# === Make Vert Table ===
# =======================
def make_vert_table(edge_table): # For Wings
	vert_table = {}
	for i in range(len(edge_table)):
		Sv = edge_table[i][0]
		Ev = edge_table[i][1]
		vert_table[Sv] = i
		vert_table[Ev] = i
	return vert_table

# ==================
# === Make Faces ===
# ==================
def make_faces(edge_table): # For Wings
	face_table = make_face_table(edge_table)
	faces=[]
	for i in range(len(face_table)):
		face_verts = []
		current_edge = face_table[i]
		while(1):
			if i == edge_table[current_edge][3]:
				next_edge = edge_table[current_edge][7] # Right successor edge
				next_vert = edge_table[current_edge][0]
			else:
				next_edge = edge_table[current_edge][5] # Left successor edge
				next_vert = edge_table[current_edge][1]
			face_verts.append(next_vert)
			current_edge = next_edge
			if current_edge == face_table[i]: break
		face_verts.reverse()
		faces.append(face_verts)
	return faces

# ====================
# === Wings To OBJ ===
# ====================
def wings2obj(filename):
	start = time.clock()
	file = open(filename, "rb")
	header = file.read(15)
	fsize, = struct.unpack(">L",  file.read(4))   # file_size - 19
	misc,  = struct.unpack(">H",  file.read(2))
	dsize, = struct.unpack(">L",  file.read(4))   # uncompressed data size
	data   = file.read(fsize-6)
	file.close()
	data = zlib.decompress(data)
	if dsize != len(data): print "ERROR: uncompressed size does not match."
	data = cStringIO.StringIO(data)
	read_chunkheader(data)	# === wings chunk ===
	data.read(4) # misc bytes
	misc, numobjs, = struct.unpack(">BL", data.read(5))

	print "# " + "filename:", filename
	print "# " + "numobjs :", numobjs
	lastvert = 0

	for obj in range(numobjs):
		read_chunkheader(data) # === object chunk ===
		misc, namelen = struct.unpack(">BH", data.read(3))
		objname = data.read(namelen)
		read_chunkheader(data) # === winged chunk ===
		edge_table = read_edges(data)
		numfaces = read_faces(data)
		verts = read_verts(data)
		read_hardedges(data)
		data.read(27)
		faces = make_faces(edge_table)
		print "# objname :", objname
		print "# numedges:", len(edge_table)
		print "# numfaces:", numfaces
		print "# numverts:", len(verts)
		print "g", '"'+objname+'"'
		# === Vertex List ===
		for i in range(len(verts)):
			x, y, z = verts[i]
			print "v % f % f % f" % (x, -z, y)  # correct for coordinate system
		# === Face List ===
		for i in range(len(faces)):
			print "f",
			#faces[i].reverse()    # Flip all face normals
			for j in range(len(faces[i])):
				print faces[i][j]+1+lastvert,
			print
		#sys.stderr.write(`lastvert`+'\n')
		lastvert += len(verts)		# Increment vertex index for each object
	file.close()
	end = time.clock()
	print '\a\r',
	sys.stderr.write("\nDone in %.2f %s" % (end-start, "seconds"))

# =======================
# === Dump Wings File ===
# =======================
def dump_wings(filename):
	import pprint
	start = time.clock()
	file = open(filename, "rb")
	header = file.read(15)
	fsize, = struct.unpack(">L",  file.read(4))   # file_size - 19
	misc,  = struct.unpack(">H",  file.read(2))
	dsize, = struct.unpack(">L",  file.read(4))   # uncompressed data size
	data   = file.read(fsize-6)
	file.close()
	data = zlib.decompress(data)
	if dsize != len(data): print "ERROR: uncompressed size does not match."
	data = cStringIO.StringIO(data)
	print "header:", header
	print read_chunkheader(data)  # === wings chunk ===
	data.read(4) # misc bytes
	misc, numobjs, = struct.unpack(">BL", data.read(5))
	print "filename:", filename
	print "numobjs :", numobjs
	for obj in range(numobjs):
		print read_chunkheader(data) # === object chunk ===
		misc, namelen = struct.unpack(">BH", data.read(3))
		objname = data.read(namelen)
		print read_chunkheader(data) # === winged chunk ===
		edge_table = read_edges(data)
		numfaces = read_faces(data)
		verts = read_verts(data)
		read_hardedges(data)

		face_table = {}  # contains an incident edge
		vert_table = {}  # contains an incident edge
		for i in range(len(edge_table)):
			face_table[edge_table[i][2]] = i  # generate face_table
			face_table[edge_table[i][3]] = i
			vert_table[edge_table[i][0]] = i  # generate vert_table
			vert_table[edge_table[i][1]] = i

		print "objname :", objname
		print "numedges:", len(edge_table)
		print "numfaces:", numfaces
		print "numverts:", len(verts)
		print
		print "�"*79
		print "edge_table:"
		pprint.pprint(edge_table)
		#for i in range(len(edge_table)): print "%2d" % (i), edge_table[i]
		print
		print "face_table:"
		pprint.pprint(face_table)
		#for i in range(len(face_table)): print "%2d %2d" % (i, face_table[i])
		print
		print "vert_table:"
		pprint.pprint(vert_table)
		#for i in range(len(vert_table)): print "%2d %2d" % (i, vert_table[i])
	file.close()
	end = time.clock()
	print '\a\r',
	sys.stderr.write("\nDone in %.2f %s" % (end-start, "seconds"))

# =========================
# === Read Wings Format ===
# =========================
def read(filename):
	start = time.clock()
	file = open(filename, "rb")
	header = file.read(15)
	fsize, = struct.unpack(">L",  file.read(4))   # file_size - 19
	misc,  = struct.unpack(">H",  file.read(2))
	dsize, = struct.unpack(">L",  file.read(4))   # uncompressed data size
	data   = file.read(fsize-6)
	#print file.tell(), "bytes"
	file.close()
	meshtools.Draw_Progress_Bar(1.0, "Decompressing Data")
	data = zlib.decompress(data)
	data = cStringIO.StringIO(data)
	read_chunkheader(data) # wings chunk
	data.read(4)		   # misc bytes
	misc, numobjs = struct.unpack(">BL", data.read(5))
	message = "Successfully imported " + os.path.basename(filename) + '\n\n'
	message += "%s %8s %8s %8s\n" % ("Object".ljust(15), "faces", "edges", "verts")
	message += "%s %8s %8s %8s\n" % ("������".ljust(15), "�����", "�����", "�����")

	for obj in range(numobjs):
		read_chunkheader(data) # object chunk
		misc, namelen = struct.unpack(">BH", data.read(3))
		objname = data.read(namelen)
		read_chunkheader(data) # winged chunk
		edge_table = read_edges(data)
		numfaces = read_faces(data)
		verts = read_verts(data)
		read_hardedges(data)
		read_mode(data)
		faces = make_faces(edge_table)
		message += "%s %8s %8s %8s\n" % (objname.ljust(15), len(faces), len(edge_table), len(verts))
		meshtools.create_mesh(verts, faces, objname)

	material = data.read()
	#for i in material[0:6]: print "%02X" % ord(i),
	#print
	Blender.Window.RedrawAll()
	meshtools.Draw_Progress_Bar(1.0, "Done")    # clear progressbar
	data.close()
	end = time.clock()
	seconds = "\nDone in %.2f %s" % (end-start, "seconds")
	message += seconds
	meshtools.print_boxed(message)

# ===============================================
# === Write The 'Header' Common To All Chunks ===
# ===============================================
def write_chunkheader(data, version, tag, name):
	data.write(struct.pack(">BB", version, tag))
	data.write(struct.pack(">BH", 0x64, len(name)))
	data.write(name)

# ===================
# === Write Faces ===
# ===================
def write_faces(data, mesh):
	numfaces = len(mesh.faces)
	data.write(struct.pack(">BL", 0x6C, numfaces))
	#for i in range(numfaces):
	#	 if not i%100 and meshtools.show_progress: meshtools.Draw_Progress_Bar(float(i)/numfaces, "Writing Faces")
	#	 data.write("\x6A")
	data.write("\x6A" * numfaces) # same, but faster than the above loop
	data.write("\x6A")

# ===================
# === Write Verts ===
# ===================
def write_verts(data, mesh):
	numverts = len(mesh.verts)
	data.write(struct.pack(">BL", 0x6C, numverts))
	for i in range(numverts):
		if not i%100 and meshtools.show_progress: meshtools.Draw_Progress_Bar(float(i)/numverts, "Writing Verts")
		data.write(struct.pack(">BLBL", 0x6C, 1, 0x6D, 24))
		#data.write("\x6c\x00\x00\x00\x01\x6D\x00\x00\x00\x30")
		x, y, z = mesh.verts[i].co
		data.write(struct.pack(">ddd", x, z, -y))
		data.write("\x6A")
	data.write("\x6A")

# ===================
# === Write Edges ===
# ===================
def write_edges(data, mesh, edge_table):
	numedges = len(edge_table)
	data.write(struct.pack(">BL", 0x6C, numedges))
	keys = edge_table.keys()
	keys.sort()
	for key in keys:
		i = edge_table[key][6]
		if not i%100 and meshtools.show_progress: meshtools.Draw_Progress_Bar(float(i)/numedges, "Writing Edges")

		if mesh.has_col:
			r1, g1, b1 = edge_table[key][7]
			r2, g2, b2 = edge_table[key][8]
			data.write("\x6C\x00\x00\x00\x02")
			data.write("\x68\x02\x64\x00\x05color")
			data.write("\x6D\x00\x00\x00\x30")
			data.write(struct.pack(">dddddd", r1, g1, b1, r2, g2, b2))
			#print "%f %f %f - %f %f %f" % (r1, g1, b1, r2, g2, b2)
		else:
			data.write("\x6C\x00\x00\x00\x01")  # BL

		#$write_chunkheader(data, 0x68, 0x09, "edge")
		data.write("\x68\x09\x64\x00\x04edge") # faster

		# Sv Ev (Reversed)
		data.write(struct.pack(">BLBL", 0x62, key[1], 0x62, key[0]))

		# Lf Rf LP LS RP RS
		for i in range(6):
			if edge_table[key][i] < 256:
				data.write(struct.pack(">BB", 0x61, edge_table[key][i]))
			else:
				data.write(struct.pack(">BL", 0x62, edge_table[key][i]))

		data.write("\x6A")

	data.write("\x6A")

# ===============================
# === Write The Material Mode ===
# ===============================
def write_mode(data, mesh):
	data.write("\x6A")
	data.write(struct.pack(">BL", 0x6C, 1))
	write_chunkheader(data, 0x68, 0x02, "mode")
	if mesh.has_col:
		data.write(struct.pack(">BH6s", 0x64, 6, "vertex"))
	else:
		data.write(struct.pack(">BH8s", 0x64, 8, "material"))
	data.write("\x6A")

# ======================
# === Write Material ===
# ======================
def write_material(data, mesh):
	data.write("\x6A")
	data.write(struct.pack(">BL", 0x6C, 1))
	write_chunkheader(data, 0x68, 0x02, "my default")

	data.write(struct.pack(">BL", 0x6C, 2))
	write_chunkheader(data, 0x68, 0x02, "maps")
	data.write("\x6A")
	write_chunkheader(data, 0x68, 0x02, "opengl")

	# === The Material Components ===
	data.write(struct.pack(">BL", 0x6C, 5))

	write_chunkheader(data, 0x68, 0x02, "diffuse")
	data.write("\x68\x04")
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)

	write_chunkheader(data, 0x68, 0x02, "ambient")
	data.write("\x68\x04")
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)

	write_chunkheader(data, 0x68, 0x02, "specular")
	data.write("\x68\x04")
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"1.00000000000000000000"+"e+000"+"\x00"*4)

	write_chunkheader(data, 0x68, 0x02, "emission")
	data.write("\x68\x04")
	data.write("\x63"+"0.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"0.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"0.00000000000000000000"+"e+000"+"\x00"*4)
	data.write("\x63"+"0.00000000000000000000"+"e+000"+"\x00"*4)

	write_chunkheader(data, 0x68, 0x02, "shininess")
	data.write("\x63"+"0.00000000000000000000"+"e+000"+"\x00"*4)

	#write_chunkheader(data, 0x68, 0x02, "twosided")
	#data.write(struct.pack(">BH4s", 0x64, 4, "true"))

	data.write("\x6A"*3)    # use *4 if no ambient light

# =====================
# === Generate Data ===
# =====================
def generate_data(objname, edge_table, mesh):
	data = cStringIO.StringIO()

	# === wings chunk ===
	write_chunkheader(data, 0x68, 0x03, "wings")

	numobjs = 1 # len(Blender.Object.GetSelected())
	data.write("\x61\x02\x68\x03") # misc bytes
	data.write(struct.pack(">BL", 0x6C, numobjs))

	# === object chunk ===
	write_chunkheader(data, 0x68, 0x04, "object")
	data.write(struct.pack(">BH", 0x6B, len(objname)))
	data.write(objname)

	# === winged chunk ===
	write_chunkheader(data, 0x68, 0x05, "winged")
	write_edges(data, mesh, edge_table)
	write_faces(data, mesh)
	write_verts(data, mesh)
	write_mode(data, mesh)
	write_material(data, mesh)
	write_ambient_light(data)
	return data.getvalue()

# ===========================
# === Write Ambient Light ===
# ===========================
def write_ambient_light(data):
	light = [	# A quick cheat ;)
	0x6C, 0x00, 0x00, 0x00, 0x01, 0x68, 0x02, 0x64, 0x00, 0x06, 0x6C, 0x69,
	0x67, 0x68, 0x74, 0x73, 0x6C, 0x00, 0x00, 0x00, 0x01, 0x68, 0x02, 0x6B,
	0x00, 0x07, 0x41, 0x6D, 0x62, 0x69, 0x65, 0x6E, 0x74, 0x6C, 0x00, 0x00,
	0x00, 0x08, 0x68, 0x02, 0x64, 0x00, 0x07, 0x76, 0x69, 0x73, 0x69, 0x62,
	0x6C, 0x65, 0x64, 0x00, 0x04, 0x74, 0x72, 0x75, 0x65, 0x68, 0x02, 0x64,
	0x00, 0x06, 0x6C, 0x6F, 0x63, 0x6B, 0x65, 0x64, 0x64, 0x00, 0x05, 0x66,
	0x61, 0x6C, 0x73, 0x65, 0x68, 0x02, 0x64, 0x00, 0x06, 0x6F, 0x70, 0x65,
	0x6E, 0x67, 0x6C, 0x6C, 0x00, 0x00, 0x00, 0x03, 0x68, 0x02, 0x64, 0x00,
	0x04, 0x74, 0x79, 0x70, 0x65, 0x64, 0x00, 0x07, 0x61, 0x6D, 0x62, 0x69,
	0x65, 0x6E, 0x74, 0x68, 0x02, 0x64, 0x00, 0x07, 0x61, 0x6D, 0x62, 0x69,
	0x65, 0x6E, 0x74, 0x68, 0x04, 0x63, 0x31, 0x2E, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x65, 0x2B, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00,
	0x00, 0x63, 0x31, 0x2E, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x65, 0x2B, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00, 0x00, 0x63, 0x31, 0x2E,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x65, 0x2B, 0x30, 0x30,
	0x30, 0x00, 0x00, 0x00, 0x00, 0x63, 0x31, 0x2E, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x65, 0x2B, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00,
	0x00, 0x68, 0x02, 0x64, 0x00, 0x08, 0x70, 0x6F, 0x73, 0x69, 0x74, 0x69,
	0x6F, 0x6E, 0x68, 0x03, 0x63, 0x30, 0x2E, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x65, 0x2B, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00, 0x00,
	0x63, 0x33, 0x2E, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x65,
	0x2B, 0x30, 0x30, 0x30, 0x00, 0x00, 0x00, 0x00, 0x63, 0x30, 0x2E, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x65, 0x2B, 0x30, 0x30, 0x30,
	0x00, 0x00, 0x00, 0x00, 0x6A, 0x68, 0x02, 0x64, 0x00, 0x07, 0x76, 0x69,
	0x73, 0x69, 0x62, 0x6C, 0x65, 0x64, 0x00, 0x04, 0x74, 0x72, 0x75, 0x65,
	0x68, 0x02, 0x64, 0x00, 0x06, 0x6C, 0x6F, 0x63, 0x6B, 0x65, 0x64, 0x64,
	0x00, 0x05, 0x66, 0x61, 0x6C, 0x73, 0x65, 0x68, 0x02, 0x64, 0x00, 0x06,
	0x79, 0x61, 0x66, 0x72, 0x61, 0x79, 0x6C, 0x00, 0x00, 0x00, 0x0B, 0x68,
	0x02, 0x64, 0x00, 0x09, 0x6D, 0x69, 0x6E, 0x69, 0x6D, 0x69, 0x7A, 0x65,
	0x64, 0x64, 0x00, 0x04, 0x74, 0x72, 0x75, 0x65, 0x68, 0x02, 0x64, 0x00,
	0x05, 0x70, 0x6F, 0x77, 0x65, 0x72, 0x63, 0x31, 0x2E, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x65, 0x2B, 0x30, 0x30, 0x30, 0x00, 0x00,
	0x00, 0x00, 0x68, 0x02, 0x64, 0x00, 0x04, 0x74, 0x79, 0x70, 0x65, 0x64,
	0x00, 0x09, 0x68, 0x65, 0x6D, 0x69, 0x6C, 0x69, 0x67, 0x68, 0x74, 0x68,
	0x02, 0x64, 0x00, 0x07, 0x73, 0x61, 0x6D, 0x70, 0x6C, 0x65, 0x73, 0x62,
	0x00, 0x00, 0x01, 0x00, 0x68, 0x02, 0x64, 0x00, 0x05, 0x64, 0x65, 0x70,
	0x74, 0x68, 0x61, 0x03, 0x68, 0x02, 0x64, 0x00, 0x0A, 0x62, 0x61, 0x63,
	0x6B, 0x67, 0x72, 0x6F, 0x75, 0x6E, 0x64, 0x64, 0x00, 0x09, 0x75, 0x6E,
	0x64, 0x65, 0x66, 0x69, 0x6E, 0x65, 0x64, 0x68, 0x02, 0x64, 0x00, 0x18,
	0x62, 0x61, 0x63, 0x6B, 0x67, 0x72, 0x6F, 0x75, 0x6E, 0x64, 0x5F, 0x66,
	0x69, 0x6C, 0x65, 0x6E, 0x61, 0x6D, 0x65, 0x5F, 0x48, 0x44, 0x52, 0x49,
	0x6A, 0x68, 0x02, 0x64, 0x00, 0x19, 0x62, 0x61, 0x63, 0x6B, 0x67, 0x72,
	0x6F, 0x75, 0x6E, 0x64, 0x5F, 0x66, 0x69, 0x6C, 0x65, 0x6E, 0x61, 0x6D,
	0x65, 0x5F, 0x69, 0x6D, 0x61, 0x67, 0x65, 0x6A, 0x68, 0x02, 0x64, 0x00,
	0x1A, 0x62, 0x61, 0x63, 0x6B, 0x67, 0x72, 0x6F, 0x75, 0x6E, 0x64, 0x5F,
	0x65, 0x78, 0x70, 0x6F, 0x73, 0x75, 0x72, 0x65, 0x5F, 0x61, 0x64, 0x6A,
	0x75, 0x73, 0x74, 0x61, 0x00, 0x68, 0x02, 0x64, 0x00, 0x12, 0x62, 0x61,
	0x63, 0x6B, 0x67, 0x72, 0x6F, 0x75, 0x6E, 0x64, 0x5F, 0x6D, 0x61, 0x70,
	0x70, 0x69, 0x6E, 0x67, 0x64, 0x00, 0x05, 0x70, 0x72, 0x6F, 0x62, 0x65,
	0x68, 0x02, 0x64, 0x00, 0x10, 0x62, 0x61, 0x63, 0x6B, 0x67, 0x72, 0x6F,
	0x75, 0x6E, 0x64, 0x5F, 0x70, 0x6F, 0x77, 0x65, 0x72, 0x63, 0x31, 0x2E,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x65, 0x2B, 0x30, 0x30,
	0x30, 0x00, 0x00, 0x00, 0x00, 0x6A, 0x68, 0x02, 0x64, 0x00, 0x07, 0x76,
	0x69, 0x73, 0x69, 0x62, 0x6C, 0x65, 0x64, 0x00, 0x04, 0x74, 0x72, 0x75,
	0x65, 0x68, 0x02, 0x64, 0x00, 0x06, 0x6C, 0x6F, 0x63, 0x6B, 0x65, 0x64,
	0x64, 0x00, 0x05, 0x66, 0x61, 0x6C, 0x73, 0x65, 0x6A, 0x6A, 0x6A]
	data.write("".join(map(chr, light)))

# ==========================
# === Write Wings Format ===
# ==========================
def write(filename):
	start = time.clock()

	objects = Blender.Object.GetSelected()
	objname = objects[0].name
	meshname = objects[0].data.name
	mesh = Blender.NMesh.GetRaw(meshname)
	obj = Blender.Object.Get(objname)

	try:
		edge_table = meshtools.generate_edgetable(mesh)
	except:
		edge_table = {}
		message = "Unable to generate\nEdge Table for mesh.\n"
		message += "Object name is: " + meshname
		meshtools.print_boxed(message)
		#return 

		if 0:
			import Tkinter, tkMessageBox
			sys.argv=['wings.pyo','wings.pyc'] # ?

			#Tkinter.NoDefaultRoot()
			win1 = Tkinter.Tk()
			ans = tkMessageBox.showerror("Error", message)
			win1.pack()
			print ans
			if ans:
				win1.quit()
			win1.mainloop()

		else:
			from Tkinter import Label
			sys.argv = 'wings.py'
			widget = Label(None, text=message)
			#widget.title("Error")
			widget.pack()
			widget.mainloop()

	data = generate_data(objname, edge_table, mesh)
	dsize = len(data)
	meshtools.Draw_Progress_Bar(0.98, "Compressing Data")
	data = zlib.compress(data, 6)
	fsize = len(data)+6
	header = "#!WINGS-1.0\r\n\032\04"
	misc = 0x8350

	file = open(filename, "wb")
	file.write(header)
	file.write(struct.pack(">L", fsize))
	file.write(struct.pack(">H", misc))
	file.write(struct.pack(">L", dsize))
	file.write(data)

	# Blender.Window.RedrawAll()
	meshtools.Draw_Progress_Bar(1.0, '')  # clear progressbar
	file.close()
	end = time.clock()
	seconds = " in %.2f %s" % (end-start, "seconds")
	message = "Successfully exported " + os.path.basename(filename) + seconds + '\n\n'
	message += "objname : " + objname + '\n'
	message += "faces   : " + `len(mesh.faces)` + '\n'
	message += "edges   : " + `len(edge_table)` + '\n'
	message += "verts   : " + `len(mesh.verts)` + '\n'
	meshtools.print_boxed(message)

# ============
# === Main ===
# ============
if __name__ == "__main__":
	try:
		import sys
		if len(sys.argv) == 1: # if no arguments are specified,
			print "                                                                "
			print "                            _-'~`-_       _-'~`-_               "
			print "                        _.-~       ~-._.-~       ~-._           "
			print "                                                                "
			print "              _________________________________________________ "
			print "                                                                "
			print "                    Copyright (c) 2002 Anthony D'Agostino       "
			print "              http://ourworld.compuserve.com/homepages/scorpius "
			print "                           scorpius@netzero.com              "
			print "                    Wings to Wavefront OBJ converter v0.6       "
			print "              _________________________________________________ "
			print "                                                                "
			print "                 Usage: python wings.py vase.wings > vase.obj   "
			sys.exit()
		class meshtools: pass
		meshtools.show_progress = 0 	# only used within Blender's environment
		filename = sys.argv[1]
		#wings2obj(filename)
		dump_wings(filename)
	except:
		wings.write("1.wings")
else:
	import Blender, meshtools
