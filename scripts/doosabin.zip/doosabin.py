#!BPY

"""
Name: ' Doo-Sabin Subdivision'
Blender: 237
Group: 'Mesh'
Tooltip: 'Subdivide selected mesh with Doo-Sabin Subdivision'
"""

__author__ = "Anthony D'Agostino (Scorpius)"
__url__ = ("blender", "elysiun",
"Author's homepage, http://www.redrival.com/scorpius")
__version__ = "0.5"

__bpydoc__ = """\
This script is a working implementation of doo-sabin subdivision. The
mesh is converted to a topology/geometry representation (raw verts and
faces lists), the subdivided mesh is stored in raw format, and converted
back to indexed format at the end.

Usage:<br>
	Select the mesh and run this script. A copy of the selected mesh
will be created, with the word "_doosabin" appended to its name.

NumPad Plus Key - Increase the resolution in
realtime<br>NumPad Minus Key - Decrease the resolution in realtime

Supported:<br>
	Should work with any mesh even non-manifolds. Handles ngons created
during subdivision and triangulates the final result.

Missing:<br>
	UV Coordinates will be lost. Todo: rewrite and add UV support.

Known issues:<br>
	The mesh cannot have duplicate vertices, and all face normals
must point outward (or inward, as long as they are all in a
consistent order).

Notes:<br>
	Edges not shared by more than one face will not show up in the
subdivided mesh.
"""

# $Id: $
#
# +---------------------------------------------------------+
# | Copyright (c) 2005 Anthony D'Agostino                   |
# | http://www.redrival.com/scorpius                        |
# | scorpius@netzero.com                                    |
# | April 30, 2005                                          |
# | Released under the Blender Artistic Licence (BAL)       |
# +---------------------------------------------------------+
# | Doo-Sabin Subdivision                                   |
# +---------------------------------------------------------+

import Blender, meshtools, vector

# =================
# === GUI Block ===
# =================
EvtReso,DooReso = 1,Blender.Draw.Create(3)
EvtText,DooText = 2,Blender.Draw.Create('')

def draw():
	global DooReso
	Blender.BGL.glClearColor(0.625, 0.5625, 0.5, 0.0) # Brown
	Blender.BGL.glClear(Blender.BGL.GL_COLOR_BUFFER_BIT)
	Blender.BGL.glColor3b(0,0,0)
	DooReso = Blender.Draw.Slider("Resolution: ", EvtReso, 10, 10, 225, 20, DooReso.val, 1, 20, 0, "Select Resolution")
	Blender.BGL.glRasterPos2i(10, 50)
	Blender.Draw.Text("http://www.redrival.com/scorpius")
	Blender.BGL.glRasterPos2i(10, 65)
	Blender.Draw.Text("Copyright (c) 2005 Anthony D'Agostino")
	Blender.BGL.glRasterPos2i(10, 80)
	Blender.Draw.Text("Doo-Sabin Subdivision")

def key_event(event, value):
	if (event==Blender.Draw.ESCKEY and not value):
		Blender.Draw.Exit()
	if (event==Blender.Draw.QKEY and not value):
		Blender.Draw.Exit()
	if (event==Blender.Draw.PADPLUSKEY and not value):
		DooReso.val += 1
		main(DooReso.val)
	if (event==Blender.Draw.PADMINUS and not value):
		DooReso.val -= 1
		if DooReso.val < 1: 
			DooReso.val = 1
			Blender.Draw.PupMenu("Subdivision Level Error%t|"+"Depth can't be less than 1")
		main(DooReso.val)

def button_event(eventnumber):
	if eventnumber:
		main(DooReso.val)
	else:
		pass
	Blender.Draw.Draw()

Blender.Draw.Register(draw, key_event, button_event)

# ======================================
# === Doo Sabin Subivision Functions ===
# ======================================
def left_shift(seq):
	return seq[1:] + seq[0:1]

def right_shift(seq):
	return seq[-1:] + seq[0:-1]

def esort(edges):
	while 1:
		swaps = 0
		for j in range(len(edges)-2):
			if edges[j][1] != edges[j+1][0]:
				edges[j+1],edges[j+2] = edges[j+2],edges[j+1] # swap
				swaps = 1
		if swaps == 0: break
	face_verts = [edge[0] for edge in edges]
	face_verts.reverse()
	return face_verts

def make_vfaces(etab):
	vert_faces = {}
	for edge in etab:
		(sv,ev) = edge
		try:
			A,B = etab[edge][1], etab[edge][2]
			C,D = etab[edge][3], etab[edge][0] 
			vert_faces.setdefault(sv, []).append((A,B))
			vert_faces.setdefault(ev, []).append((C,D))
		except IndexError:
			pass # this edge is not shared by more than one face
	vert_faces = map(esort, vert_faces.values())
	return vert_faces

def doo_sabin(verts, faces, depth):
	numfaces = len(faces)
	face_faces = []
	etab = {}
	for i in range(numfaces):
		T = meshtools.centroid(verts, faces[i])
		numverts = len(faces[i])
		seq2 = [verts[j] for j in faces[i]]
		edges = zip(seq2, left_shift(seq2))
		edge_centers = map(vector.vavg, edges)
		t = [T]*numverts
		v = seq2
		w = edge_centers
		x = right_shift(edge_centers)
		fverts = zip(t,v,w,x)
		fverts = map(vector.vavg, fverts)
		face_faces.append(fverts)
		fverts = zip(fverts, left_shift(fverts))
		for edge in edges:
			sv,ev = edge
			PA,PB = fverts[edges.index(edge)]
			if (ev,sv) in etab: etab[(ev,sv)].extend([PB,PA])
			else: etab[(sv,ev)] = [PB,PA]
	edge_faces = etab.values()
	vert_faces = make_vfaces(etab)
	edge_faces = [rawface for rawface in edge_faces if len(rawface) > 2]
	vert_faces = [rawface for rawface in vert_faces if len(rawface) > 2]
	raw_faces = face_faces + vert_faces + edge_faces
	if depth==1: return (raw_faces)
	verts, faces = meshtools.raw_to_indexed(raw_faces)
	return doo_sabin(verts, faces, depth-1)

# ============
# === Main ===
# ============
def main(depth):
	if Blender.Window.EditMode(): Blender.Window.EditMode(0)
	objects = Blender.Object.GetSelected()
	objname = objects[0].name
	meshname = objects[0].data.name
	ext = "_doosabin"
	if ext in meshname:
		index = meshname.index(ext)
		meshname = meshname[0:index]
		objname = meshname	
	mesh = Blender.NMesh.GetRaw(meshname)
	meshtools.overwrite_mesh_name = 1
	verts = [tuple(vert) for vert in mesh.verts]
	faces = [[vert.index for vert in face.v] for face in mesh.faces]
	raw_faces = doo_sabin(verts, faces, depth)
	verts, faces = meshtools.raw_to_indexed(raw_faces)
	meshtools.create_mesh(verts, faces, objname+ext)
	Blender.Window.DrawProgressBar(1.0, '')  # clear progressbar
	Blender.Window.RedrawAll()
