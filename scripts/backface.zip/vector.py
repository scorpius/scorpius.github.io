# +-------------------------------------------------------------+
# | Copyright (c) 2001 Anthony C. D'Agostino                    |
# | http://ourworld.compuserve.com/homepages/scorpius           |
# | scorpius@compuserve.com                                     |
# | March 27, 2001                                              |
# +-------------------------------------------------------------+
# | Backface Culling Script v0.2                                |
# | Vector Functions                                            |
# +-------------------------------------------------------------+

from math import *

# returns a vector [u+v]
def vadd(u, v):
    return [u[0]+v[0], u[1]+v[1], u[2]+v[2]]

# returns a vector from point v to point u [u-v]
def vsub(u, v):
    return [u[0]-v[0], u[1]-v[1], u[2]-v[2]]

# returns a vector [u*v] Cross Product
def vcross(u, v):
    return [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]

# returns a vector [u*scalar]
def vmul(u, s):
    return [u[0]*s, u[1]*s, u[2]*s]

# returns a vector of unit length (normalized)
def vunit(u):
    return vmul(u, 1/vlen(u))


# returns a real number (Dot Product)
def vdot(u, v):
    return u[0]*v[0] + u[1]*v[1] + u[2]*v[2]

# returns a real number (Vector Length)
def vlen(u):
    return sqrt(u[0]**2 + u[1]**2 + u[2]**2)

# Test functions
if __name__ == "__main__":
    t = (sqrt(5)-1)/2
    a = [0, 1, t]
    b = [0, 1, -t]

    print 'a             :', a
    print 'b             :', b
    print
    print 'vadd(a, b)    :', vadd(a, b)
    print 'vsub(a, b)    :', vsub(a, b)
    print 'vcross(a, b)  :', vcross(a, b)
    print 'vmul(b, 3)    :', vmul(b, 3)
    print
    print 'vdot(a, b)    :', vdot(a, b)
    print 'vlen(a)       :', vlen(a)
    print 'vlen(b)       :', vlen(b)
    print 'vunit(a)      :', vunit(a)
    print 'vunit(b)      :', vunit(b)
    print 'vdot(ua, ub)  :', vdot(vunit(a), vunit(b))
    print 'vcross(ua, ub):', vcross(vunit(a), vunit(b)), vunit(vcross(a, b) )

    print 'Angle         :', acos(vdot(vunit(a), vunit(b)))*180/pi
