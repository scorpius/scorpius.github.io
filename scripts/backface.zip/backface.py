# +-------------------------------------------------------------+
# | Copyright (c) 2001 Anthony C. D'Agostino                    |
# | http://ourworld.compuserve.com/homepages/scorpius           |
# | scorpius@compuserve.com                                     |
# | March 27, 2001                                              |
# +-------------------------------------------------------------+
# | Backface Culling Script v0.2                                |
# | All polygons (in the selected mesh) which are facing away   |
# | from the camera are removed.  Make sure all face normals    |
# | are pointing outward (c|n) and apply size/rotation (c|a).   |
# | Results in a 20% to 50% reduction in rendering time.        |
# | Warning: This script overwrites the original mesh.          |
# +-------------------------------------------------------------+

import Blender, vector

from Blender import NMesh, Object
from math import *
from time import *

start = clock()

object = Object.GetSelected()
meshname = object[0].data.name
mesh  = NMesh.GetRaw(meshname)
mesh1 = NMesh.GetRaw()

# Makes a copy of the entire vertex list, even though
# some vertices are not used in the new mesh (fix this).
for vertex in mesh.verts:
    mesh1.verts.append(vertex)

camera = Object.Get("Camera")

back=0

for face in mesh.faces:
    vertex1 = face.v[0]
    vertex2 = face.v[1]
    vertex3 = face.v[2]

    v = vector.vsub(vertex1.co, camera.loc)
    p = vector.vsub(vertex2.co, vertex1.co)
    q = vector.vsub(vertex3.co, vertex1.co)
    a = vector.vcross(p, q)
    dotprod = vector.vdot(a, v)

    # v is a vector from the camera to the first vertex of a face
    # p is a vector from 1st to 2nd vertex
    # q is a vector from 1st to 3rd vertex
    # a is the Face Normal (the cross product of vectors 'p' and 'q')

    if dotprod < 0:
        mesh1.faces.append(face)
    else:
        back = back+1

NMesh.PutRaw(mesh1, meshname)
end = clock()

print back, "faces removed in",
print "%.2f %s" % (end-start, "seconds"),
print "%s%d%s" % ("(", int(back/(end-start)), " faces per second).")
