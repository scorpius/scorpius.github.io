# +---------------------------------------------------------+
# | Copyright (c) 2007-2010 Anthony D'Agostino              |
# | http://chronosphere.home.comcast.net					|
# | scorpius@netzero.com									|
# | August 3, 2007											|
# | Read UVs & Normals from LWO files exported from MoI3D	|
# +---------------------------------------------------------+
# | Note: Export with the vertex-welding option turned off. |
# +---------------------------------------------------------+

import struct, chunk, io, time, bpy
from import_scene_obj import unpack_face_list, unpack_list
from pprint import pprint

def read_vmap(lwochunk):
	data = io.BytesIO(lwochunk.read())
	ctype = data.read(4)
	cdime, = struct.unpack(">H", data.read(2))
	cname = read_nstring(data)
	namelen = len(cname)
	nstrsize = (namelen+1 if namelen%2 else namelen+2)
	dsize = lwochunk.chunksize - (4+2+nstrsize)
	if ctype == b"NORM":
		norms = []
		i = 0
		while (i < dsize):
			index,idxsize = read_vx(data)
			x,y,z = struct.unpack(">fff", data.read(12))
			norms.append((x,-z,y))
			i += 12+idxsize
		return (b"NORM",norms)
	elif ctype == b"TXUV":
		txuvs = []
		i = 0
		while (i < dsize):
			index,idxsize = read_vx(data)
			u,v = struct.unpack(">ff", data.read(8))
			txuvs.append((u,v))
			i += 8+idxsize
		return (b"TXUV",txuvs)
	else:
		print(ctype)
		return (b"NONE",[])

def read_verts(lwochunk):
	data = io.BytesIO(lwochunk.read())
	numverts = int(lwochunk.chunksize/12)
	verts = []
	for i in range(numverts):
		x,y,z = struct.unpack(">fff", data.read(12))
		verts.append((x,z,y))
	return verts

def read_nstring(data):
	name = b""
	while 1:
		char = data.read(1)
		if char == b"\0":
			break
		else:
			name += char
	if not len(name)%2: # if even, read one more null
		data.read(1)
	return name.decode().title()

def read_vx(data):
	byte1, = struct.unpack(">B", data.read(1))
	if byte1 != 0xFF:	 # 2-byte index
		byte2, = struct.unpack(">B", data.read(1))
		index = byte1*256 + byte2
		idxsize = 2
	else:				 # 4-byte index
		byte2, byte3, byte4 = struct.unpack(">3B", data.read(3))
		index = byte2*65536 + byte3*256 + byte4
		idxsize = 4
	return (index,idxsize)

def read_layr(lwochunk):
	data = io.BytesIO(lwochunk.read())
	idx, flags = struct.unpack(">hh", data.read(4))
	pivot = struct.unpack(">fff", data.read(12))
	layer_name = read_nstring(data)
	if not layer_name: layer_name = "No Name"
	return layer_name

def read_faces(lwochunk):
	data = io.BytesIO(lwochunk.read())
	polygon_type = data.read(4) # "FACE"
	faces = []
	i = 0
	while(i < lwochunk.chunksize-4):
		facev = []
		i += 2
		numfaceverts, = struct.unpack(">H", data.read(2))
		for j in range(numfaceverts):
			index,idxsize = read_vx(data)
			i += idxsize
			facev.append(index)
		facev.reverse()
		faces.append(facev)
	return faces

def create_mesh(verts, faces, objname, norms, uvs):
	mesh = bpy.data.meshes.new(str(objname))
	mesh.add_geometry(int(len(verts)), 0, int(len(faces)))
	mesh.verts.foreach_set("co", unpack_list(verts))
	mesh.verts.foreach_set("normal", unpack_list(norms))
	mesh.faces.foreach_set("verts_raw", unpack_face_list(faces))
	mesh.faces.foreach_set("smooth", [True]*len(unpack_face_list(faces)))
	return mesh

def add_mesh_obj(mesh, objname):
	scn = bpy.context.scene
	for o in scn.objects:
		o.selected = False
	nobj = bpy.data.objects.new(objname, mesh)
	scn.objects.link(nobj)
	nobj.selected = True
	if scn.objects.active == None or scn.objects.active.mode == 'OBJECT':
		scn.objects.active = nobj

def read(filename):
	time1 = time.time()
	file = open(filename, "rb")
	form_id, form_size, form_type = struct.unpack(">4s1L4s", file.read(12))
	allvs,allfs,allos,allns,allts = [],[],[],[],[]
	print(filename)
	while 1:
		try:
			lwochunk = chunk.Chunk(file)
		except EOFError:
			print("Done")
			break
		if lwochunk.chunkname == b"LAYR":
			objname = read_layr(lwochunk)
			allos.append(objname)
		elif lwochunk.chunkname == b"PNTS":
			verts = read_verts(lwochunk)
			allvs.append(verts)
		elif lwochunk.chunkname == b"POLS":
			faces = read_faces(lwochunk)
			allfs.append(faces)
		elif lwochunk.chunkname == b"VMAP":
			(ctype,data) = read_vmap(lwochunk)
			if ctype == b"NORM":
				norms = data
				allns.append(norms)
			elif ctype == b"TXUV":
				txuvs = data
				allts.append(txuvs)
			else:
				print("Unknown ctype:", ctype)
		elif lwochunk.chunkname == b"VMAD":
			msg = "Please export with the vertex-welding option turned off!"
			Blender.Draw.PupMenu("Incorrect MOI Meshing Options%t|"+msg)

		else:
			lwochunk.skip()
	objs = list(zip(allvs,allfs,allos,allns,allts))
	#pprint(objs)
	print("Number of objects:", len(objs))
	for obj in objs:
		print(objname)
		verts, faces, objname, norms, txuvs = obj
		mesh = create_mesh(verts, faces, objname, norms, txuvs)
		add_mesh_obj(mesh, objname)
	time2 = time.time()
	print("Total import time is: %.2f seconds.\n" % (time2 - time1))


from bpy.props import *
class IMPORT_OT_moi3d_lwo(bpy.types.Operator):
	'''Import Moi with Normals via (.lwo)'''
	bl_idname = "import_scene.moi"
	bl_label = 'Import MOI'
	filepath = StringProperty(name="File Path",
						description="Filepath used for importing the LWO file",
						maxlen= 1024, default= "")

	def execute(self, context):
		read(self.properties.filepath)
		return {'FINISHED'}

	def invoke(self, context, event):
		wm = context.manager
		wm.add_fileselect(self)
		return {'RUNNING_MODAL'}

def menu_func(self, context):
	self.layout.operator(IMPORT_OT_moi3d_lwo.bl_idname,
						 text="MoI with Normals (.lwo)")

def register():
	bpy.types.register(IMPORT_OT_moi3d_lwo)
	bpy.types.INFO_MT_file_import.append(menu_func)

def unregister():
	bpy.types.unregister(IMPORT_OT_moi3d_lwo)
	bpy.types.INFO_MT_file_import.remove(menu_func)

if __name__ == "__main__":
	register()
