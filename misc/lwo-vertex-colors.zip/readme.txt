Here are some sample LWO files exported from Blender.

---------------
cornell-box.lwo
---------------
This is just a plain old mesh taken directly from the original Cornell
Box Data. There is one quad that emits light. The other objects (also
made up of quads) are each on their own layer. My script does this
automatically. Use this file if you want to test your own renderer. Also
available in native Blender format on my site.

------------------
vc-cornell-box.lwo
------------------
Here's one possible radiosity solution that was done in Blender 1.80 a
few years ago. This was solved in about 30 minutes and rendered in 3
seconds on a PII 450MHz. This mesh has vertex colors applied.

---------
plane.lwo
---------
A single quad with 4 vertex colors to test the smooth gradients.

----------------------------------------------
tetrahedron.lwo, torus-knot.lwo, and torus.lwo
----------------------------------------------
These use per-face vertex colors and were generated with my custom
python script. Note the specular highlights on the torus models.



All of these files include the following chunks: ICON, TEXT, and DESC.
The 7.5 demo displays a question mark instead of the icon. And there
seems to be no way to access the TEXT and DESC chunks. If anyone knows
how to do this, please let me know. Also note how the objects are placed
on separate layers; the layer name is set to the object name.

January 4, 2004
Anthony D'Agostino
scorpius@compuserve.com
http://ourworld.compuserve.com/homepages/scorpius
